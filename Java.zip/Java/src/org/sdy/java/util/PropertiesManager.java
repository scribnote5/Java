package org.sdy.java.util;

import java.io.*;
import java.util.*;

public class PropertiesManager {
	
	public static Properties getProperties(String path) throws IOException{
		Properties properties = new Properties();
		// 현재 경로에서 프로퍼티 파일 로딩
		properties.load(new BufferedInputStream(new FileInputStream("./"+path)));		
		
		return properties;
	}
	
	// classpath경로 상의 문자열로 파일명의 경로를 반환
	public static String getPath(String path) throws IOException{
		ClassLoader loader = Thread.currentThread().getContextClassLoader();
		String proPath = loader.getResource(path).getPath(); 
		
		return proPath;
	}
	
}
