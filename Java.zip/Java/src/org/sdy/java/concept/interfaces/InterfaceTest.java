package org.sdy.java.concept.interfaces;
/**
 * 인터페이스 테스트
 * 
 * @author scrib
 *
 */
public class InterfaceTest {
	public static void main(String[] args) {
		ProgrammingService programminService = new ProgrammingServiceImpl();
		programminService.introduceProgramming();
		programminService.selectProgramming();
		// 정적 메소드 실행
		ProgrammingService.studyProgramming();
	}	
}
