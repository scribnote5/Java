package org.sdy.java.concept.interfaces;

/**
 * 인터페이스
 * 
 * <pre>
 * 	객체의 사용 방법을 정의한 타입으로 교환성과 다형성 구현의 중요한 역할 
 * 	개발 코드와 객체가 서로 통신하는 접점 역할을 함 
 * 	개발 코드가 인터페이스의 메소드 호출시 인터페이스는 객체의 메소드를 호출(가상 메소드 호출) 
 * 	객체 내부 구조를 알 필요 없고 인터페이스의 메소드만 알면 됨
 * 	개발 코드 변경 없이 사용하는 객체를 변경할 수 있음으로 실행내용과 리턴값을 다양화
 * </pre>
 */

public interface ProgrammingService {
	// public static final 자동 생략
	// 상수 사용 가능하지만 권고하는 방법 아님
	String FIELD = "Web";
	String LANGAUGE = "Java, Jsp";
	int MARKET_SCALE = 2;

	// 메소드 종류는 public abstract 자동 생략
	// 추상 메소드 : 구현받는 클래스 필수 구현 
	void introduceProgramming();

	// 자바 8 부터 디폴트 메소드와 정적 메소드 사용 가능
	// 디폴트 메소드 
	// 구현 받은 클래스는 메소드 실행 가능
	// 기존 인터페이스의 이름과 추상 메소드 변경 없이 디폴트 메소드만 추가할 수 있기 때문에 이전에 개발한 구현 클래스를 그대로 사용할 수 있으면서 새롭게 개발하는 클래스는 디폴트 메소드 활용
	default void selectProgramming() {
		System.out.println("분야를 선택하세요.");
	}

	// 정적 메소드 : 바로 호출 가능
	static void studyProgramming() {
		System.out.println("공부합니다.");
	}
}
