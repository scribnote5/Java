package org.sdy.java.concept.interfaces;

public class ProgrammingServiceImpl implements ProgrammingService {

	@Override
	public void introduceProgramming() {
		System.out.println("프로그래밍을 소개합니다.");	
	}

	public void selectProgramming() {
		System.out.println("분야를 선택하세요. 오버라이딩");
	}
}
