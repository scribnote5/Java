package org.sdy.java.concept.io.stream;

import java.io.*;

/**
 * 입출력 스트림 테스트
 * 
 * <pre>
 * [입출력 스트림 클래스 구조]
 * 		바이트 기반 스트림   	      |     	문자 기반 스트림
 * 입력 스트림        |   출력 스트림      |   입력 스트림   	|  출력 스트림
 * InputStream | OutputStream |    Reader   |  Writer 
 * 
 * [기본적인 입력 스트림 메소드] 
 *  바이트를 읽을 수 없으면 -1 반환
 *  int = read() : 입력 스트림으로부터 1바이트를 읽고 바이트 반환 
 *  int = read(byte[] b) : 입력 스트림으로부터 매개변수로 주어진 바이트 배열 길이만큼 바이트 배열에 저장하고 읽은 바이트수 반환
 *  
 *  입력 스트림으로 부터 100개의 바이트가 들어오면 
 *  read() 메소드는 100번 반복 
 *  read(byte[] b) 메소드는 한 번 읽을 때 바이트 배열 길이만큼 읽기에 반복횟수가 줄음
 *  => 많은 양의 바이트를 읽을 경우read(byte[] b) 메소드 사용
 *  
 * [기본적인 출력 스트림 메소드] 
 *  void = write(int b) : 출력 스트림으로 1바이트를 보냄
 *  void = write(byte[] b) : 매개변수로 주어진 바이트 배열의 모든 바이트를 출력 스트림으로 보냄
 *  void = write(int b) : 출력 스트림으로 1바이트를 보냄
 *  void = flush() : 출력 스트림 내부에 작은 버퍼를 비우는 역할 
 *  => 더이상 출력할 것이 없으면 마지막으로 호출 필수
 *  
 *  close() : 자원을 사용하면 자원을 닫기는 필수
 * </pre>
 * 
 * @author scribnote5
 *
 */

public class BufferedStreamTest {

	public static void main(String[] args) throws Exception {
		int data;
		String str;

		/*
		 * 성능 향상 보조 스트림 : 프로그램이 입출력 소스와 직접 작업하지 않고 중간에 메모리 버퍼와 작업함으로서 실행 성능 향상 => 속도가 매우
		 * 빠르기에 입출력 스트림에서 필수로 사용!
		 * 
		 */
		try {
			// 바이트 기반 스트림
			BufferedInputStream bis = new BufferedInputStream(new FileInputStream("file.txt"));
			BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream("file.txt"));

			// 문자 기반 스트림 : 문자를 읽을 때 사용하자!
			BufferedReader br = new BufferedReader(new FileReader("file.txt"));
			BufferedWriter bw = new BufferedWriter(new FileWriter("file.txt"));

			// 문자 기반 스트림의 출력 스트림 사용
			bw.write("성능 향상 보조 스트림 테스트 입니다.\n성능 향상 보조 스트림 테스트 입니다.\n");
			// 출력 스트림 사용 안 하는 경우 버퍼 비우기 필수!
			bw.flush();

			/*
			 * 바이트 기반 스트림 읽어오기
			 */
			// BufferedInputStream 스트림의 read(byte) 메소드 사용
			byte[] buf = new byte[256];

			while ((data = bis.read(buf)) != -1) {
				String text = new String(buf, 0, buf.length);
				System.out.println(text);
			}

			// BufferedInputStream 스트림의 read() 메소드 사용시 바이트 단위로 읽어오는데 한글은 2바이트 이므로 한글이 깨짐
			// while((data = bis.read()) != -1) {
			// System.out.print((char) data);
			// }

			/*
			 * 문자 기반 스트림 읽어오기
			 */
			// BufferedReader 스트림은 한 줄씩 읽은 readLine 메소드가 특별히 존재
			while ((str = br.readLine()) != null) {
				System.out.println(str);
			}

			// BufferedReader 스트림의 read() 메소드 사용
			// while ((data = br.read()) != -1) {
			// System.out.print((char) data);
			// }

			// 출력 스트림 사용 안 하는 경우 버퍼 비우기 필수!
			bos.flush();
		} catch (Exception e) {

		}

		/*
		 * 문자 변환 보조 스트림 : 바이트 기반 스트림에서 입출력 데이터가 문자인 경우 변환하여 사용 => 문자셋 종류 및 다양한 문자 출력에서
		 * 유리
		 */
		BufferedReader r = new BufferedReader(
				new InputStreamReader(new BufferedInputStream(new FileInputStream("file.txt"))));
		BufferedWriter w = new BufferedWriter(
				new OutputStreamWriter(new BufferedOutputStream(new FileOutputStream("file.txt"))));

		w.write("문자 변환 보조 스트림 테스트 입니다.\n문자 변환 보조 스트림 테스트 입니다.");
		w.flush();

		// 다음과 같이 readLine 메소드 사용 가능하며 그 이외에도 입출력 데이터가 문자인 경우 꼭 변환하자!
		while ((str = r.readLine()) != null) {
			System.out.println(str);
		}

		w.close();
		r.close();
	}

}
