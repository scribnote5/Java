package org.sdy.java.concept.io.file;

import java.io.*;

/**
 * 파일 입출력 테스트
 * 
 * <pre>
 * [파일 입출력 메소드]
 *  boolean = file.exists(); : 파일 또는 디렉터리 존재 여부 확인
 *  boolean = file.createNewFile(); : 새로운 파일 생성
 *  boolean = file.mkdir(); : 새로운 디렉토리 생성
 *  boolean = file.mkdirs(); : 경로상에 없는 모든 디렉토리 생성
 *  boolean = file.delete(); : 파일 또는 디렉토리 삭제
 *  
 *  String = file.getName(); : 파일 이름
 *  String = file.getPath(); : 전체 경로
 *  long = file.length = 파일 크기 
 * </pre>
 * 
 * @author scribnote5
 *
 */
public class FileTest {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		
		System.out.println("파일 구분자 : " + File.separator);
		// 파일 객체 생성(파일이나 디렉터리 생성은 아님)
		File file = new File("image.jpg");
		
		// File 스트림 생성
		FileInputStream fis = new FileInputStream(new File("image.jpg"));	
		FileOutputStream fos = new FileOutputStream(new File("image_copy.jpg"));	
		
		// 버퍼를 이용한 File 스트림 생성(훨씬 빠르므로 이것을 사용)
		BufferedInputStream bis = new BufferedInputStream(new FileInputStream(new File("image.jpg")));
		BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(new File("image_copy.jpg")));
		
		long start =0 ;
		long end =0 ;
		int data;
		
		start=System.currentTimeMillis();
		while((data = fis.read()) != -1) {
			fos.write(data);
		}
		end=System.currentTimeMillis();
		System.out.println("일반 파일 스트림 시간 : " + (end - start));

		start=System.currentTimeMillis();
		while((data = bis.read()) != -1) {
			bos.write(data);
		}
		end=System.currentTimeMillis();
		System.out.println("버퍼를 이용한 파일 스트림 시간 : " + (end - start));

	}
}
