package org.sdy.java.concept.io.stream;

import java.io.*;

/**
 * 입출력 스트림 테스트
 * 
 * <pre>
 * [입출력 스트림 클래스 구조]
 * 		바이트 기반 스트림   	      |     	문자 기반 스트림
 * 입력 스트림        |   출력 스트림      |   입력 스트림   	|  출력 스트림
 * InputStream | OutputStream |    Reader   |  Writer 
 * 
 * [기본적인 입력 스트림 메소드] 
 *  바이트를 읽을 수 없으면 -1 반환
 *  int = read() : 입력 스트림으로부터 1바이트를 읽고 바이트 반환 
 *  int = read(byte[] b) : 입력 스트림으로부터 매개변수로 주어진 바이트 배열 길이만큼 바이트 배열에 저장하고 읽은 바이트수 반환
 *  
 *  입력 스트림으로 부터 100개의 바이트가 들어오면 
 *  read() 메소드는 100번 반복 
 *  read(byte[] b) 메소드는 한 번 읽을 때 바이트 배열 길이만큼 읽기에 반복횟수가 줄음
 *  => 많은 양의 바이트를 읽을 경우read(byte[] b) 메소드 사용
 *  
 * [기본적인 출력 스트림 메소드] 
 *  void = write(int b) : 출력 스트림으로 1바이트를 보냄
 *  void = write(byte[] b) : 매개변수로 주어진 바이트 배열의 모든 바이트를 출력 스트림으로 보냄
 *  void = write(int b) : 출력 스트림으로 1바이트를 보냄
 *  void = flush() : 출력 스트림 내부에 작은 버퍼를 비우는 역할 
 *  => 더이상 출력할 것이 없으면 마지막으로 호출 필수
 *  
 *  close() : 자원을 사용하면 자원을 닫기는 필수
 * </pre>
 * 
 * @author scribnote5
 *
 */

public class ObjectStreamTest {

	public static void main(String[] args) throws Exception {
		/*
		 * 객체 입출력 보조 스트림 객체 직렬화 : 객체의 데이터를 일렬로 늘어선 연속적인 바이트로 변경하는 작업 역직렬화 : 연속적인 바이트를
		 * 객체로 복원하는 작업 serialVersionUID : 같은 클래스임을 알려주는 식별자
		 */
		ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("file.txt"));
		MemberVo memberVo = new MemberVo();
		oos.writeObject(memberVo);
		// 출력 스트림 사용 안 하는 경우 버퍼 비우기 필수!
		oos.flush();

		ObjectInputStream ois = new ObjectInputStream(new FileInputStream("file.txt"));
		MemberVo memberVo2 = (MemberVo) ois.readObject();
		System.out.println("역직렬화로 받은 객체 : " + memberVo2);
		System.out.println("역직렬화로 받은 부모 객체의 필드 : " + memberVo2.country);
		
		// 사용 안하는 자원 닫기 필수!
		oos.close();
		ois.close();
	}

}
