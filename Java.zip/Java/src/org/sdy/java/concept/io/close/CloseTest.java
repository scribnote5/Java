package org.sdy.java.concept.io.close;

import java.io.*;

/**
 * 자원 닫기 테스트
 * 
 * @author scribnote5
 *
 */

public class CloseTest {

	public static void main(String[] args) {
		BufferedInputStream bis = null;
		BufferedOutputStream bos = null;

		// try 자동 자원 닫기는 사용하지 말자!(복잡함)
		try {
			bis = new BufferedInputStream(new FileInputStream("file.txt"));
			bos = new BufferedOutputStream(new FileOutputStream("file.txt"));

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 자원 닫기는 필수! 
			if (bis != null) { try { bis.close(); } catch (Exception e) { e.printStackTrace(); } }
			if (bos != null) { try { bos.close(); } catch (Exception e) { e.printStackTrace(); } }
			
			// 간편하게 사용하는 자원 닫기
			close(bis);
			close(bos);
		}

	}

	// 자원 닫는 편리한 정적 메소드
	public static void close(Closeable c) {
		if (c == null)
			return;
		try {
			c.close();
		} catch (IOException e) { 
			e.printStackTrace();
		}
	}

}
