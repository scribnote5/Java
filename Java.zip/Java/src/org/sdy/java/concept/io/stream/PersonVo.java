package org.sdy.java.concept.io.stream;

public class PersonVo {
	public String country ="korea";
}
