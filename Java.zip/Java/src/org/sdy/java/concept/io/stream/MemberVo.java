package org.sdy.java.concept.io.stream;

import java.io.*;

import lombok.*;

/**
 * 직렬화 가능한 클래스
 * 
 * <pre>
 * 	Serialiazable 인터페이스를 구현한 클래스만 직렬화 가능
 * 
 * [부모 클래스의 필드를 직렬화하는 방법]
 *  1. 부모 클래스에 Serializable 인터페이스 구현
 *  2. 자식 클래스에서 writeObject(), readObject() 메소드 선언하여 부모 객체 필드 직접 출력
 * </pre>
 * 
 * @author scribnote5
 *
 */

@ToString
public class MemberVo extends PersonVo implements Serializable {
	// serialVersionUID를 명시적으로 선언 가능
	static final long serialVersionUID = 1L;

	private String id = "sdy";
	private String password = "123";
	private String name = "송대영";
	private int level = 1;
	// static 키워드 필드는 직렬화 제외
	private static String hobby = "수영";

	// 접근 제한자가 private인 경우만 자동 호출
	private void writeObject(ObjectOutputStream out) throws Exception {
		// 부모 객체 필드값 출력
		out.writeUTF(country);
		// 자식 객체의 필드를 직렬화
		out.defaultWriteObject();
	}

	// 접근 제한자가 private인 경우만 자동 호출
	private void readObject(ObjectInputStream in) throws Exception {
		// 부모 객체 필드값 출력
		country = in.readUTF();
		// 자식 객체의 필드를 직렬화
		in.defaultReadObject();
	}
}
