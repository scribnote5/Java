package org.sdy.java.concept.inheritance;

/**
 * 추상클래스
 * 
 * <pre>
 * 	클래스들의 공통적인 특성을 추출해서 선언한 클래스
 * 	추상 클래스와 실체 클래스는 상속의 관계이며 실체 클래스는 추상 클래스의 모든 특성을 물려받고 필드 매소드의 특징을 가짐
 * 	객체를 직접 생성해서 사용 불가
 * 
 * 	[용도]
 * 	실체 클래스들이 공통된 필드와 메소드의 이름을 통일할 목적
 * 	실체 클래스를 작성할 때 시간 절약
 * </pre>
 * 
 * @author scrib
 *
 */
public abstract class Phone {
	public String name = "핸드폰";

	public Phone() {
	}

	public Phone(String name) {
		this.name = name;
	}

	void turnOn() {
		System.out.println("핸드폰을 킵니다.");
	}

	void turnOff() {
		System.out.println("핸드폰을 끕니다.");
	}

	// 추상클래스에서 선언하는 메소드의 선언부만 있고 메소드 실행 내용인 중괄호가 없는 메소드
	// 하위 클래스가 반드시 실행 내용을 채우도록 강요하고 싶은 메소드가 있을 경우
	// 추상메소드 상속받는 자식클래스는 필수적으로 구현
	abstract void printName();

}
