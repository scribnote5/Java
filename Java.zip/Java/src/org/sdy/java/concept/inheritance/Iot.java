package org.sdy.java.concept.inheritance;

public class Iot extends Programming {
	String prospect;

	public Iot() {
	}

	public Iot(String field, String language, String prospect) {
		setField(field);
		setLangauge(language);
		this.prospect = prospect;
	}

	public Iot(String field, String language, String prospect, int marketScale) {
		super(field, language);
		this.prospect = prospect;
		setMarketScale(marketScale);
	}

	public void introduceProgramming() {
		System.out.println("IOT를 소개합니다.");
	}
	
	public void selectProgramming() {
		// 부모 메소드 호출 
		super.introduceProgramming();
		System.out.println("IOT 분야를 선택하세요");
	}
}