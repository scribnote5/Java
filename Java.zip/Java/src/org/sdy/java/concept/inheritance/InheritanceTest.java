package org.sdy.java.concept.inheritance;

/**
 * 상속 테스트
 * 
 * @author scrib
 *
 */
public class InheritanceTest {

	public static void main(String[] args) {
		// 상속 
		Iot iot = new Iot();
		iot.selectProgramming();

		// 추상 클래스 
		SmartPhone phone = new SmartPhone("스마트폰");	
		phone.printName();
	}
}