package org.sdy.java.concept.inheritance;

import lombok.*;

@Data
public class Programming {
	private String field;
	private String langauge;
	private int marketScale;

	/* constructor */
	public Programming() {
		marketScale += 100;
	}

	public Programming(String langauge) {
		this(); // 기본 생성자 speed++ 기능 재활용
		this.langauge = langauge;
	}

	public Programming(String langauge, String field) {
		this(langauge); // Programming(String langauge) 생성자의 speed++, this.langauge 기능 재활용
		this.field = field;
	}
	
	/* method */
	public void introduceProgramming() {
		System.out.println("프로그래밍을 소개합니다.");
	}

	public void selectProgramming() {
		System.out.println("분야를 선택하세요.");
	}
}