package org.sdy.java.concept.inheritance;

public class SmartPhone extends Phone{
	// 생성자 필수
	public SmartPhone(String name) {
		super(name);
	}

	@Override
	// 추상메소드 구현 
	void printName() {
		System.out.println("스마트폰 입니다.");
		
	}

}
