package org.sdy.java.concept.generic;

/**
 * 제네릭 메소드
 * 
 * <pre>
 * 	[제네릭 메소드]
 * 	매개 타입과 리턴 타입으로 타입 파라미터를 갖는 메소드
 * 
 * 	public <타입 파라미터...> 리턴타입 메소드명(매개변수...)
 * </pre>
 * 
 * @author scribnote5
 *
 */
public class BoxUtil {
	public <T> Box<T> boxing(T t) {
		Box<T> box = new Box<T>();
		box.set(t);
		return box;
	}

}