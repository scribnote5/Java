package org.sdy.java.concept.generic;

/**
 * <pre>
 * 	[제네릭]
 *	클래스 설계시 구체적인 타입을 명시하지 않음
 * 	실제 클래스 사용시 구체적인 타입을 지정함으로 타입 변환을 최소화	
 * 
 * 	[용도]
 * 	1. 컴파일시 강한 타입 체크 	
 * 	2. 불필요한 타입 변환 제거 => 저장시 타입 변환, 읽을시 타입 변환 되기에 성능 하락
 *  ex) 
 *  List list = new ArrayList();
 *  list.add("hello");
 *  String str = (String) list.get(0); // 불필요한 타입변환
 * </pre>
 * 
 * @author scribnote5
 *
 */
public class GenericTest {
	
	public static void main(String[] args) {
		// 기존 
		Box<String> box = new Box<String>();
		// 자바 7부터 <> 연산자를 통하여 간단하게 작성 가능
		Box<String> box1 = new Box<>();
		
		box1.set("box"); // 자동 Boxing
		box1.get(); // 자동 UnBoxing

		// 제네렉 메소드 테스트
		BoxUtil boxUtil = new BoxUtil();
		Box<String> box2 = boxUtil.boxing("박스이름");
		Box<Integer> box3 = boxUtil.boxing(123);
		
		
		
	}

}
