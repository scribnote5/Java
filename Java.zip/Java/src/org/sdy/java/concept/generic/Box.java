package org.sdy.java.concept.generic;

/**
 * 제네릭 사용
 * 
 * @author scribnote5
 *
 * @param <T>
 */

public class Box<T> {
	T t;

	public T get() {
		return t;
	}

	public void set(T t) {
		this.t = t;
	}

}

// 타입 파라미터 T : 임의로 정한 변수
// 타입 파라미터 T는 <> 연산자안의 타입으로 변경되어 다음과 같이 자동으로 재구성
// ex) Box<String> box = new Box<String>();
// public class Box<String> {
// String t;
//
// public String get() {
// return t;
// }
//
// public void set(String t) {
// this.t = t;
// }
// }
