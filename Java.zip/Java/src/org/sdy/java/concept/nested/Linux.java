package org.sdy.java.concept.nested;

/**
 * <pre>
 * 	[중첩 클래스]
 * 
 * 	클래스 내부에 선언한 클래스
 * 	두 클래스 멤버들을 서로 쉽게 접근할 수 있음
 * 	외부에는 불필요한 관계 클래스를 감춤으로 코드의 복잡성을 줄임
 * </pre>
 * 
 * @author scribnote5
 *
 */
public class Linux {
	// 자바 7까지는 반드시 final 키워드를 붙여야 로컬 클래스에서 사용 가능
	double version;
	String name = "Linux";

	// 인스턴스 멤버 클래스
	class Ubuntu {
		Ubuntu() {
			version = 16.04;
		}

		String name = "Ubuntu";
		int preference = 2;

		void printOs() {
			System.out.println("바깥 객체 참조 : " + Linux.this.name);
			System.out.println("중첩 객체 참조 : " + this.name);
			System.out.println(version);
			System.out.println();
		}
	}

	// 정적 멤버 클래스
	static class CentOs {
		CentOs() {
			// static이 아니므로 사용불가
			// version = 7.0;
		}

		String name = "CentOs";
		static int preference;

		void printOs() {
			System.out.println(this.name);
			System.out.println("버전이 확인되지 않았습니다.");
			System.out.println();
		}
	}

	// 정적 멤버 클래스는 static으로 선언 가능
	static CentOs centOs = new CentOs();
	// 인스턴스 멤버 클래스는 static 선언 불가능
	// static Ubuntu ubuntu = new Ubuntu();

	void buyRedHat() {
		// 로컬 클래스
		class RedHat {
			RedHat() {
				version = 6.2;
			}

			String name = "RedHat";
			int preference = 3;

			void printOs() {
				System.out.println(this.name);
				System.out.println(version);
				System.out.println();
			}
		}
		RedHat redHat = new RedHat();
		redHat.name = "changed RedHat";
		redHat.printOs();
	}

}
