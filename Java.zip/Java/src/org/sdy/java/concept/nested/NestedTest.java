package org.sdy.java.concept.nested;

/**
 * 중첩 클래스, 인터페이스 테스트
 * 
 * @author scribnote5
 *
 */
public class NestedTest {

	public static void main(String[] args) {
		// 중첩 클래스
		// 인스턴스 멤버 클래스
		Linux linux = new Linux();
		Linux.Ubuntu ubuntu = linux.new Ubuntu();
		ubuntu.printOs();
		
		// 정적 멤버 클래스
		Linux.CentOs centOs = new Linux.CentOs();
		centOs.printOs();
		
		// 로컬 클래스
		// Linux linux = new Linux();
		linux.buyRedHat();
		
		//중첩 인터페이스
		Button btn = new Button();
		btn.setOnclickListner(new CallListener());
		btn.touch();
		
		btn.setOnclickListner(new MessageListener());
		btn.touch();
		
	}

}
