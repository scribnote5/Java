package org.sdy.java.concept.nested;

/**
 * <pre>
 *  [중첩 인터페이스] 
 * 
 * 	주로 UI 프로그래밍에서 이벤트 처리 목적으로 활용
 * </pre>
 * 
 * @author scribnote5
 *
 */
public class Button {
	OnClickListener listener;

	// 매개변수의 다형성
	void setOnclickListner(OnClickListener listener) {
		this.listener = listener;
	}

	void touch() {
		listener.onClick();
	}

	// 중첩 인터페이스
	interface OnClickListener {
		void onClick();
	}
}

// 인터페이스 구현
class CallListener implements Button.OnClickListener {
	@Override
	public void onClick() {
		System.out.println("전화를 겁니다.");
	}

}

// 인터페이스 구현
class MessageListener implements Button.OnClickListener {
	@Override
	public void onClick() {
		System.out.println("메세지를 겁니다.");
	}

}
