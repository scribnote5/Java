package org.sdy.java.concept.exception;

/**
 * 예외처리 테스트
 * 
 * <pre>
 *  예외처리 방법
 *  1. try{ } catch{ }
 *  2. throws 예외던지기 => 예외를 던지는 경우 사용하는 곳에서 try { } catch { }를 사용하거나 다시 throws 예외를 던져야함.
 * </pre>
 * 
 * @author scrib
 *
 */

public class ExceptionTest {

	public static void main(String[] args) {
		int balance = 10000;
		int money = 20000;

		Account account = new Account();
		try {
			account.withdraw(balance, money);
		} 
		// 멀티 catch : 여러개의 예외를 하나의 catch에 등록 가능  
		catch (AccountException | NumberFormatException e) {
			// 예외 메시지
			System.err.println(e.getMessage());
			// 예외 메시지 + 예외내용
			System.err.println(e);
			// 예외 상세내용
			e.printStackTrace();
		}
	}

}
