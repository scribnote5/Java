package org.sdy.java.concept.exception;

public class Account {
	public void withdraw(int balance, int money) throws AccountException {
		if (balance < money) {
			// 예외 발생
			throw new AccountException("잔고가 모자랍니다.");
		}
	}

}
