package org.sdy.java.concept.casting;

public class Bus extends Vehicle {
	@Override
	public void run() {
		System.out.println("버스가 달립니다.");
	}
	
	public void ride() {
		System.out.println("버스에 탑승합니다.");
	}
}