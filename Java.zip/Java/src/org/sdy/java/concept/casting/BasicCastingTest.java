package org.sdy.java.concept.casting;

/**
 * 자꾸 까먹는 기본 자료형 형변환 테스트
 * 
 * @author scribnote5
 *
 */
public class BasicCastingTest {

	public static void main(String[] args) {
		int a = 100;
		String b = "200";
		
		// 정수형 => 문자열 
		System.out.println(String.valueOf(a));
		// 문자열 => 정수형
		System.out.println(Integer.parseInt(b));
	}

}
