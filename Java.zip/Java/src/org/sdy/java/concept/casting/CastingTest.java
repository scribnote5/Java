package org.sdy.java.concept.casting;

/**
 * 형 변환 테스트
 * 
 * <pre>
 * 	크기 : 부모 > 자식
 * 	변환 : 자식 => 부모(o), 부모 => 자식(x)
 * 	큰 것이 작은 것에 들어갈 수 없음
 * </pre>
 * 
 * @author scrib
 *
 */

public class CastingTest {
	public static void main(String[] args) {
		Vehicle vehicle = new Vehicle();
		Vehicle taxi = new Taxi();
		Vehicle bus = new Bus();

		Taxi taxi2 = new Taxi();
		Bus bus2 = new Bus();

		// 각각 다른 값이 출력
		vehicle.run();
		taxi.run();
		bus.run();
		System.out.println();

		// 다운 캐스팅
		((Taxi) taxi).ride();
		((Bus) bus).ride();
		System.out.println();

		// 업 캐스팅
		((Vehicle) taxi2).call();
		((Vehicle) bus2).call();
		System.out.println();

		// 형변환
		System.out.println(taxi instanceof Vehicle);
		System.out.println(vehicle instanceof Taxi);
		System.out.println(bus instanceof Taxi);

	}

}
