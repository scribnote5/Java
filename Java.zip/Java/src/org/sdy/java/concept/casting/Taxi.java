package org.sdy.java.concept.casting;

public class Taxi extends Vehicle {
	@Override
	public void run() {
		System.out.println("택시가 달립니다.");
	}
	
	public void ride() {
		System.out.println("택시에 탑승합니다.");
	}

}