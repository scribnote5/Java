package org.sdy.java.concept.casting;

public class Vehicle {
	public void run() {
		System.out.println("차량이 달립니다.");
	}

	public void call() {
		System.out.println("차량을 부릅니다.");
	}
}
