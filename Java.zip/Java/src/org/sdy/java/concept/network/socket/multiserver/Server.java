package org.sdy.java.concept.network.socket.multiserver;

import java.net.*;
import java.util.*;

/**
 * 소켓 테스트
 * 
 * @author scribnote5
 *
 */
public class Server {

	public static void main(String[] args) {
		
		List<String> connectionList = Collections.synchronizedList(new ArrayList<String>());
		Socket socket = null;
		ServerSocket serverSocket = null;
		
		
		
		try {
			 serverSocket.bind(new InetSocketAddress("localhost", 5001));


//			ExecutorService executorService =  null; 
			
			while (true) {
				System.out.println("연결 대기중");
				
				// 쓰레드 풀에서 쓰레드 생성
//				executorService = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
				
				// 쓰레드가 블로킹 상태(요청이 오기전까지 대기상태로 어떤 작업도 진행 불가)
				socket = serverSocket.accept();
				
				// 쓰레드 생성
				ServerThread thread = new ServerThread(socket);
				thread.start();
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally { 
//			if(serverSocket != null) { try {  serverSocket.close(); } catch (Exception e) { e.printStackTrace(); } }
//			if(socket != null) { try { socket.close(); } catch (Exception e) { e.printStackTrace(); } }
//			if(br != null) { try { br.close(); } catch (Exception e) { e.printStackTrace(); } }
//			if(os != null) { try { os.close(); } catch (Exception e) { e.printStackTrace(); } }
		}
	}

}
