package org.sdy.java.concept.network.ip;

import java.net.*;

/**
 * ip 테스트
 * 
 * @author scribnote5
 *
 */

public class ipTest {

	public static void main(String[] args) throws Exception {
		String host = "www.naver.com";

		// 단 하나의 IP 주소를 얻음
		InetAddress ia = InetAddress.getByName(host);
		// DNS에 등록된 모든 IP를 얻음
		InetAddress[] iaArr = InetAddress.getAllByName(host);
		// 내 컴퓨터 IP주소
		InetAddress local = InetAddress.getLocalHost();

		System.out.println("내 컴퓨터 ip주소 : " + local.getHostAddress());

	}
}
