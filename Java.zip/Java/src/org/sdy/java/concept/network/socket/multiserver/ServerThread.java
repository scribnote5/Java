package org.sdy.java.concept.network.socket.multiserver;

import java.io.*;
import java.net.*;

public class ServerThread extends Thread {

	Socket socket = null;
	BufferedReader br = null;
	BufferedWriter bw = null;
	String str = null;
	
	public ServerThread() {
		super();
	}

	public ServerThread(Socket socket) {
		this.socket = socket;
	}

	@Override
	public void run() {
		System.out.println("ServerStartThread 쓰레드가 시작합니다.");
		InetSocketAddress isa = (InetSocketAddress) socket.getRemoteSocketAddress();
		System.out.println("연결 수락 Client ip, port : " + isa.getHostName() + ":" + isa.getPort());

		 try {
			br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
			
			while ((str = br.readLine()) != null) {
				System.out.println("데이터 받기 성공 : " + str);
				bw.write(str);
			}	
			
		} catch (IOException e) {
			e.printStackTrace();
		}	
	}
}
