package org.sdy.java.concept.network.socket.client;

import java.io.*;
import java.net.*;

public class ClientSocketTest {

	public static void main(String[] args) {
		Socket socket = new Socket();
		String data = "Client 데이터\nClient 데이터\n";

		try {
			System.out.println("연결 요청");
			socket.connect(new InetSocketAddress("localhost", 5001));
			System.out.println("연결 성공");

			OutputStream os = socket.getOutputStream();
			byte[] bytes = data.getBytes("UTF-8");
			os.write(bytes);
			os.flush();
			System.out.println("데이터 보내기 성공");

			InputStream is = socket.getInputStream();
			bytes = new byte[200];
			int readByteCount = is.read(bytes);
			data = new String(bytes, 0, readByteCount, "UTF-8");
			System.out.println("데이터 받기 성공 : " + data);

			os.close();
			is.close();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try { socket.close(); } catch (IOException e) { e.printStackTrace(); }
		}
 		

	}

}
