package org.sdy.java.concept.network.socket.server;

import java.io.*;
import java.net.*;

/**
 * 소켓 테스트
 * 
 * @author scribnote5
 *
 */
public class ServerSocketTest {

	public static void main(String[] args) {
		String data;
		Socket socket = null;
		ServerSocket serverSocket = null;

		try {
			// 포트 바인딩하는 3가지 방법
			serverSocket = new ServerSocket(5001);
			// serverSocekt.bind(new InetSocketAddress("localhost", 5001));
			// serverSocekt.bind(new InetSocketAddress(5001));

			while (true) {
				System.out.println("연결 대기중");
				// 쓰레드가 블로킹 상태(요청이 오기전까지 대기상태로 어떤 작업도 진행 불가)
				socket = serverSocket.accept();
				InetSocketAddress isa = (InetSocketAddress) socket.getRemoteSocketAddress();
				System.out.println("연결 수락 Client ip, port : " + isa.getHostName() + ":" + isa.getPort());

				InputStream is = socket.getInputStream();
				byte[] bytes = new byte[200];
				// 상대방이 데이터를 보내기전까지 블로킹 상태가 되며 상대방이 데이터를 보냄, 정상적으로 socket.close(), 비정상적 종료(IOException) 호출시 블로킹 해제
				int readByteCount = is.read(bytes);
				System.err.println(readByteCount);
				data = new String(bytes, 0, readByteCount, "UTF-8");
				System.out.println("데이터 받기 성공 : " + data);

				OutputStream os = socket.getOutputStream();
				data = "Server 데이터";
				bytes = data.getBytes("UTF-8");
				os.write(bytes);
				os.flush();

				is.close();
				os.close();
				socket.close();
			}

		} catch (Exception e) {
			e.printStackTrace();

			if (!serverSocket.isClosed()) {
				try {
					serverSocket.close();
				} catch (Exception e1) {
				}
			}
		} finally {

		}
	}
	
	public void receiveSocket(Socket socket) {
		
	}

}
