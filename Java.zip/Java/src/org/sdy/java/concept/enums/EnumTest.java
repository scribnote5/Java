package org.sdy.java.concept.enums;

/**
 * enum 테스트
 * 
 * @author scrib
 *
 */
public class EnumTest {

	public static void main(String[] args) {
		// enum 데이터 출력
		System.out.println(Programming.IOT.getProgramming());
		System.out.println(Programming.WEB.getProgramming());
		System.out.println(Programming.BIG_DATA.getProgramming());
		System.out.println(Programming.AI.getProgramming());
	}
}
