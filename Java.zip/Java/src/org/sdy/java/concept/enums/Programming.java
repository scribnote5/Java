package org.sdy.java.concept.enums;

public enum Programming {
	IOT("사물 인터넷"), 
	WEB("웹"), 
	BIG_DATA("빅데이터"), 
	AI("인공지능");

	private String programming;

	private Programming(String programming) {
		this.programming = programming;
	}

	public String getProgramming() {
		return this.programming;
	}
}