package org.sdy.java.concept.anonymous;

/**
 * 익명 객체 테스트
 * 
 * <pre>
 * 	일회성의 구현 객체를 만들기 위해 소스 파일을 만들고 클래스를 선언하는 것은 비효율적
 * 	소스 파일을 만들지 않고도 구현 객체를 만들 수 있는 방법 
 * 	자바는 UI 프로그래밍에서 이벤트 처리하기 위해 임시 작업 스레드를 만들기 위해 사용
 * </pre>
 * 
 * @author scrib
 *
 */
public class AnonymousTest {
	public static void main(String[] args) {
		ProgrammingService programming = new ProgrammingService() {
			// 추상 메소드 구현
			@Override
			public void introduceProgramming() {
				System.out.println("프로그래밍을 소개합니다.");
			}

			// 디폴트 메소드 구현
			@Override
			public void selectProgramming() {
				System.out.println("분야를 선택하세요.");
			}
		};

		programming.introduceProgramming();
		programming.selectProgramming();
		// 정적 메소드 실행
		ProgrammingService.studyProgramming();
		
		// 익명 구현 객체와 중첩 클래스 적용
		Programming programming2 = new Programming();
		programming2.print();
		
	}
}
