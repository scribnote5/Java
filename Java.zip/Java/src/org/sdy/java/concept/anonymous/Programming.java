package org.sdy.java.concept.anonymous;

/**
 * <pre>
 * 	익명 구현 객체와 중첩 클래스
 * </pre>
 * 
 * @author scribnote5
 *
 */
public class Programming {
	void print() {
		// 로컬 클래스
		ProgrammingService programming = new ProgrammingService() {
			// 추상 메소드 구현
			@Override
			public void introduceProgramming() {
				System.out.println("프로그래밍을 소개합니다.");
			}

			// 디폴트 메소드 구현
			@Override
			public void selectProgramming() {
				System.out.println("분야를 선택하세요.");
			}
		};
		
		programming.introduceProgramming();
		programming.selectProgramming();
	}

}
