package org.sdy.java.concept.thread.synchronize;

/**
 * <pre>
 *  [동기화]
 * 	스레드 사용 중인 객체가 다른 객체를 다른 객체가 변경할 수 없도록 객체에 잠금을 걸걸어 사용할 수 없도록 해야함
 * 	임계영역 : 단 하나의 스레드만 실행할 수 있는 코드 영역
 * 	임계 영역을 지정시 synchronized 사용하며 한 번에 한 스레드만 실행
 *  
 *  [활용]
 *  메소드, 블록(공유 객체)
 *  
 *  [현재 동기화를 구현할 수 있는 방법]
 *  1. User Class에서 synchronized 메소드 사용
 *  2. User Class에서 synchronized 블럭 사용
 *  3. PrintTask Class에서 synchronized 블럭 사용
 * </pre>
 * 
 * @author scribnote5
 *
 */
class User {
	int num = 0;

	// 1. User Class에서 synchronized 메소드 사용
	public synchronized void add() {
		System.out.println(++num + "번");

		// 2. User Class에서 synchronized 블럭 사용
		// synchronized (공유 객체) { } // this : 자기 자신을 의믜
		// synchronized (this) {
		// System.out.println(++num + "번");
		// }

	}
}
