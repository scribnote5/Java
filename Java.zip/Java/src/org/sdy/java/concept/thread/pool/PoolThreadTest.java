package org.sdy.java.concept.thread.pool;

import java.util.concurrent.*;

/**
 * 쓰레드 풀 테스트
 * 
 * <pre>
 * [쓰레드 풀]
 *  작업 처리에 사용되는 쓰레드를 제한된 개수만큼 정해 놓음 
 *  작업 큐(Queue)에 들어오는 작업들을 하나씩 쓰레드가 맡아 처리
 *  작업 처리가 끝난 쓰레드는 다시 작업 큐에서 새로운 작업을 가져와 처리
 * </pre>
 * 
 * @author scribnote5
 *
 */
public class PoolThreadTest {
	public static void main(String[] args) throws Exception {
		/*
		 * 쓰레드 풀 생성
		 */
		// 쓰레드 풀의 초기 쓰레드 수 : 0개
		// 최소 유지 쓰레드 수 : 0개
		// 최대 쓰레드 수 : Integer.MAX_VALUE개
		// 운영체제의 성능과 상황에 따라 최대 쓰레드 수는 달라짐
		// 1개 이상의 쓰레드가 추가되었을 경우 60초 동안 추가된 스레드가 아무 작업을 하지 않으면 추가된 쓰레드를 종료하고 풀에서 제거
		ExecutorService executorService1 = Executors.newCachedThreadPool();

		// 쓰레드 풀의 초기 쓰레드 수 : 0개
		// 최소 유지 쓰레드 수 : nThreads개
		// 최대 쓰레드 수 : nThreads개
		// 쓰레드가 작업을 처리하지 않고 놀고 있더라도 쓰레드 개수가 줄지 않음
		ExecutorService executorService2 = Executors.newFixedThreadPool(3);

		// 직접 ThreadPoolExcecutror 객체 생성
		ExecutorService executorService3 = new ThreadPoolExecutor(
				Runtime.getRuntime().availableProcessors(), // 최소 유지 쓰레드 수(CPU 코어의 수만큼 최대 스레드를 사용하는 스레드풀을 생성)
				100, // 최대 스레드 개수
				120L, // 놀고 있는 시간 
				TimeUnit.SECONDS, // 놀고 있는 시간 단위 
				new SynchronousQueue<Runnable>()
		);
		
		// 작업 생성
		ExecutorService executorService = Executors.newFixedThreadPool(3);

		/*
		 * Runnable, Callable 클래스 구현 
		 */
		for (int i = 0; i < 10; i++) {
			// Runnable 구현 클래스 : 작업 후 완료 리턴값 없음
			Runnable task = new Runnable() {
				@Override
				public void run() {
					ThreadPoolExecutor threadPoolExecutor = (ThreadPoolExecutor) executorService;

					int poolSize = threadPoolExecutor.getPoolSize();
					String threadName = Thread.currentThread().getName();
					System.out.println("[총 스레드 개수: " + poolSize + "] 작업 스레드 이름: " + threadName);

					int value = Integer.parseInt("숫자 형변환 에러 발생");
				}
			};
			
			//Callable 구현 클래스 : 작업 후 완료 리턴값 있음
//			Callable<String> task = new Callable<String>() {
//				@Override
//				public String call() throws Exception {
//					ThreadPoolExecutor threadPoolExecutor = (ThreadPoolExecutor) executorService;
//					
//					int poolSize = threadPoolExecutor.getPoolSize();
//					String threadName = Thread.currentThread().getName();		
//					System.out.println("[총 스레드 개수: " + poolSize + "] 작업 스레드 이름: " + threadName);
//	
//					int value = Integer.parseInt("숫자 형변환 에러 발생");
//	
//					return "성공";
//				}
//			};

			/* 
			 * 쓰레드  실행
			 */
			// 작업 처리 결과를 얻을 수 있음
			// 예외가 발생하더라도 쓰레드는 종료되지 않고 계속 재사용되어 다른 작업을 처리
			// Future 객체는 작업이 완료될 때까지 기다렸다가 최종 결과를 얻는데 사용  
			Future future = executorService.submit(task);
			
			// 작업을 처리하는 쓰레드가 작업을 완료하기 전까지는 get() 메소드가 블로킹되므로 다른 코드 실행불가
			// get() 메소드를 호출하기 위해 새로운 쓰레드 생성
			new Thread(new Runnable() {
				@Override
				public void run() {
					try {
						// 작업이 완료될 때까지 블로킹 되었다가 처리 결과 리턴
						future.get();
					} catch (Exception e) {
						System.err.println("에러가 발생했습니다.");
					}
				}
				
			}).start();
			
			Thread.sleep(100);
		}
		
		// 쓰레드 풀 종료
		// 현재 처리 중인 작업, 작업 큐에 대기하고 있는 모든 작업 처리후 종료
		executorService.shutdown(); 
		// 남아 있는 작업 상관없이 종료
		executorService.shutdownNow(); 

	}
}
