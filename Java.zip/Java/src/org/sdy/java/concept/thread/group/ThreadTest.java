package org.sdy.java.concept.thread.group;

/**
 * 쓰레드 그룹 테스트
 * 
 * <pre>
 * [쓰레드 그룹]
 *  관련된 쓰레드를 묶어서 관리
 *  JVM이 실행되면 system 쓰레드 그룹을 만들고 JVM 운영에 필요한 쓰레드들을 생성해서 system 쓰레드 그룹에 포함 
 *  system의 하위 쓰레드 그룹으로 main을 만들고 main 쓰레드를 main 쓰레드 그룹에 포함
 *  쓰레드는 반드시 하나의 그룹에 포함
 *  명시적으로 쓰레드 그룹에 포함시키지 않으면 기본적으로 자신을 생성한 쓰레드와 같은 그룹에 속함 
 * </pre>
 */
import java.util.*;

public class ThreadTest {
	public static void main(String[] args) {
		AutoSaveThread autoSaveThread = new AutoSaveThread();
		autoSaveThread.setName("AutoSaveThread");
		autoSaveThread.setDaemon(true);
		autoSaveThread.start();

		// 프로세스 내에서 실행하는 모든 쓰레드에 대한 정보를 얻음
		Map<Thread, StackTraceElement[]> map = Thread.getAllStackTraces();
		Set<Thread> threads = map.keySet();

		for (Thread thread : threads) {
			System.out.println("Name: " + thread.getName() + ((thread.isDaemon()) ? "(Daemon)" : "(Main)"));
			System.out.println("소속그룹: " + thread.getThreadGroup().getName());
		}

		System.out.println();

		/*
		 * 명시적으로 쓰레드 그룹 생성
		 */
		// 쓰레드 그룹을 지정하지 않으면 현재 쓰레드가 속한 그룹의 하위 그룹으로 생성
		ThreadGroup threadGroup1 = new ThreadGroup("쓰레드 그룹1");
		// threadGroup1 쓰레드의 하위 그룹 생성
		ThreadGroup threadGroup2 = new ThreadGroup(threadGroup1, "쓰레드 그룹2");

		ThreadGroup myGroup = new ThreadGroup("myGroup");
		WorkThread wThreadA = new WorkThread(myGroup, "wThreadA");
		WorkThread wThreadB = new WorkThread(myGroup, "wThreadB");

		wThreadA.start();
		wThreadB.start();


	}
}
