package org.sdy.java.concept.thread.pool;

import java.util.concurrent.*;

/**
 * 
 * 작업 처리 결과를 외부 객체에 저장 테스트
 * 
 * <pre>
 * 	작업 결과를 외부 객체에 저장
 *  두 개 이상의 쓰레드 작업을 취합할 목적으로 이용
 * </pre>
 * 
 * @author scribnote5
 *
 */
public class ExternalThreadTest {

	public static void main(String[] args) {
		ExecutorService executorService = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());

		System.out.println("작업 처리 요청");

		class Task implements Runnable {
			// 외부 Result 객체를 필드에 저장
			Result result;

			// 생성자를 통해 Result 객체 주입
			Task(Result result) {
				this.result = result;
			}

			@Override
			public void run() {
				int sum = 0;

				for (int i = 1; i <= 10; i++) {
					sum += i;
				}

				// Result 객체에 작업 결과 저장
				result.addValue(sum);
			}
		}
		;

		Result result = new Result();
		Runnable task1 = new Task(result);
		Runnable task2 = new Task(result);

		// 쓰레드가 작업을 완료할 때까지 블로킹되었다가 작업을 완료하면 result 객체 리턴
		// Future get() 메소드 호출시 쓰레드가 작업 완료할 떄까지 블로킹되었다가 작업을 완료하면 V타입 객체 리턴
		Future<Result> future1 = executorService.submit(task1, result);
		Future<Result> future2 = executorService.submit(task2, result);

		try {
			result = future1.get();
			result = future2.get();
			System.out.println("처리 결과: " + result.accumValue);
			System.out.println("처리 완료");
		} catch (Exception e) {
			e.printStackTrace();
		}

		executorService.shutdown();
	}
}

// 처리 결과를 저장하는 Result 클래스
class Result {
	int accumValue;

	synchronized void addValue(int value) {
		accumValue += value;
	}
}
