package org.sdy.java.concept.thread.synchronize;

/**
 * Thread 테스트
 * 
 * @author scribnote5
 *
 */

public class ThreadTest {

	public static void main(String[] args) {

		User user = new User();

		// 3개의 스레드 객체 생성
		PrintTask thread1 = new PrintTask(user);
		PrintTask thread2 = new PrintTask(user);
		PrintTask thread3 = new PrintTask(user);

		// 스레드 시작
		thread1.start();
		thread2.start();
		thread3.start();
	}
}
