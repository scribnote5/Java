package org.sdy.java.concept.thread.synchronize;

public class PrintTask extends Thread{
	User user;

	public PrintTask(User user) {
		this.user = user;
	}

	public void run() {
		for (int i = 0; i < 3; i++) {
			// 3. PrintTask Class에서 synchronized 블럭 사용
			// synchronized (user) {
			user.add();
			// }

		}
	}
}
