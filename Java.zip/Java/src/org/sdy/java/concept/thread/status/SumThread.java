package org.sdy.java.concept.thread.status;

public class SumThread extends Thread {

	public int sum;

	@Override
	public void run() {
		for (int i = 0; i < 100; i++) {
			sum += i;
		}
	}

}
