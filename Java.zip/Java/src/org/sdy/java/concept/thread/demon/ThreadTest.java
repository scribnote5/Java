package org.sdy.java.concept.thread.demon;

/**
 * 데몬 쓰레드 테스트
 * 
 * @author scribnote5
 *
 */
public class ThreadTest {

	public static void main(String[] args) {
		AutoSaveThread autoSaveThread = new AutoSaveThread();
		// 주 쓰레드가 데몬이 될 쓰레드를 설정
		autoSaveThread.setDaemon(true);
		autoSaveThread.start();

		try {
			// 3초동안 데몬 쓰레드를 호출
			Thread.sleep(3000); 
		} catch (InterruptedException e) {
		}

		// 메인 쓰레도 종료시 데몬 쓰레드 종료
		System.out.println("메인 쓰레드 종료");
	}
}
