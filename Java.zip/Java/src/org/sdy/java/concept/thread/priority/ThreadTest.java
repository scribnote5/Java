package org.sdy.java.concept.thread.priority;

/**
 * Thread 테스트
 * 
 * @author scribnote5
 *
 */
public class ThreadTest {

	public static void main(String[] args){
		for (int i = 1; i < 10; i++) {
			// 완벽한 결과로 맞아 떨어지지 않지만 늦게 시작함(우선 순위가 높음) 쓰레드가 먼저 끝남
			PrintTask thread = new PrintTask(i + " 중요도가 높은 ");
			thread.setPriority(i + 1);
			thread.start();
		}
	}
}
