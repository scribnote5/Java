package org.sdy.java.concept.thread.status;

/**
 * Thread 테스트
 * 
 * <pre>
 * 	sleep : 주어진 시간동안 일시 정지 
 * 	yield : 다른 쓰레드에게 실행 양보후 실행 대기 상태
 *  join : 다른 쓰레드의 종료를 기다림
 *  notify : 일시 정지 상태에 있는 스레드를 실행 대기 상태로 만듬
 *  notifyAll : 일시 정지 상태에 있는 모든 스레드를 실행 대기 상태로 만듬
 *  wait : 자신은 두 번 실행되지 않도록 일시정지 상태로 만듬 
 *  interrupt : 쓰레드가 일시 정지 상태에 있을 경우 예외를 발생시켜 run() 메소드를 정상 종료, stop 메소드는 자원들이 불안전한 상태로 남겨지기에 사용 금지
 * </pre>
 * 
 * @author scribnote5
 *
 */
public class ThreadTest {

	public static void main(String[] args) {

		/*
		 * 쓰레드 상태 출력
		 */
		PrintTask thread = new PrintTask();
		System.out.println("쓰레드 상태 : " + thread.getState());
		thread.start();

		/*
		 * 쓰레드 상태제어
		 */
		try {
			// 주어진 시간동안 일시정지
			Thread.sleep(500);
			System.out.println("쓰레드 상태 : " + thread.getState());
		} catch (Exception e) {
		}
		System.out.println();

		/*
		 * 쓰레드 양보
		 */
		ThreadA threadA = new ThreadA();
		ThreadB threadB = new ThreadB();

		threadA.start();
		threadB.start();

		System.err.println("B실행");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		threadA.work = false;

		System.err.println("A, B실행");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		threadA.work = true;

		System.err.println("A, B실 종료");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		threadA.stop = true;
		threadB.stop = true;

		/*
		 * 쓰레드 종료 기다림
		 */
		SumThread sumThread = new SumThread();
		sumThread.start();
		try {
			// sumThread가 종료할 때까지 메인 스레드를 일시정지
			sumThread.join();
		} catch (InterruptedException e) {
		}

		System.out.println(sumThread.sum);

		/*
		 * 쓰레드 간 협업
		 */
		DataBox dataBox = new DataBox();

		ProducerThread producerThread = new ProducerThread(dataBox);
		ConsummerThread consummerThread = new ConsummerThread(dataBox);

		producerThread.start();
		consummerThread.start();

		/*
		 * 쓰레드 종료
		 */
		Thread thread2 = new Thread(new PrintTask2());
		thread2.start();
		thread.interrupt();

	}
}
