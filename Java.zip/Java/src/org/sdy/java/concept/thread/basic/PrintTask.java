package org.sdy.java.concept.thread.basic;

/**
 * <pre>
 *	프로세스 : 실행 중인 하나의 애플리케이션                                                                                       
 *  멀티 태스킹 : 두 가지 이사으이 작업을 동시에 처리하는 것 => 멀티 스레드                                                                   
 *	스레드 : 하나의 코드 실행 흐름이며 한 프로스 내에 스레드가 두개라면 두 개의 코드 흐름이 생기며 병렬처리, 네트워크 통신, 다수 클라이언트의 요청을 처리하는 서버 개발에 사용
 * </pre>
 * 
 * @author scribnote5
 *
 */

// Thread 하위 클래스로부터 생성 extends Thread
public class PrintTask extends Thread {
	int a;
	@Override
	public void run() {
		System.out.println("extends Thread 쓰레드가 시작합니다.");
	}
}

// Thread 클래스로 부터 직접 생성 implements Runnable
// implements 하는 경우 해당 클래스의 필드를 사용할 수 없음
class PrintTask2 implements Runnable {
	public void run() {
		System.out.println("implements Runnable 쓰레드가 시작합니다.");
	}
}
