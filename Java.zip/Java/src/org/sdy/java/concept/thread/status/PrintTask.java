package org.sdy.java.concept.thread.status;

/**
 * <pre>
 * 	[스레드 상태]						                    반복
 * 	스레드 객체 생성(NEW) => 실행 대기(RUNNABLE) <= 일시정지 => 실행 => 종료(TERMINATED)
 * 
 *  [일시정지 상태]
 *  1. WAITING : 다른 스레드가 통지할 때까지 기다리는 상태
 *  2. TIME_SAITING : 주어진 시간 동안 기다리는 상태
 *  3. BLOCKED : 사용하고자 하는 객체의 락이 풀릴 때까지 기다리는 상태
 * 
 * </pre>
 * 
 * @author scribnote5
 *
 */

// Thread 클래스로 부터 직접 생성 implements Runnable
public class PrintTask extends Thread {

	public void run() {
		// 스레드 상태 얻기
		Thread.State state = Thread.currentThread().getState();
		System.out.println("쓰레드 상태 : " + state);

		// 상수값으로 비교 가능
		// if (state == Thread.State.NEW) {
		// System.out.println("쓰레드 상태 : NEW");
		// }

	}
}
