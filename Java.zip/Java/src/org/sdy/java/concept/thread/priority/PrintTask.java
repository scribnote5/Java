package org.sdy.java.concept.thread.priority;

/**
 * <pre>
 *	동시성 : 멀티 작업을 위해 하나의 코어에서 멀티 스레드가 번갈아가며 실행
 *	병렬성 : 멀티 작업을 위해 멀티 코어에서 개별 스레드를 동시에 실행
 *	
 *	싱글 코어 CPU를 이용한 멀티 스레드 작업은 병렬적으로 실행되는 것처럼 보이지만 번갈아 길행하는 것이 빠른 동시성 작업
 *
 *	[스레드 스케줄링]
 *	우선순위 : 1, MIN_PRIORITY(가장 낮음) ~ 10, MAX_PRIORITY(가장 높음)
 *	순환 할당(Round-Robin) : 시간 할당량을 정해서 하나의 스레드를 정해진 시간만큼만 실행하는 방식으로 JVM에서 시간관리를 하기에 코드로 제어 불가
 * </pre>
 * 
 * @author scribnote5
 *
 */

// Thread 클래스로 부터 직접 생성 implements Runnable
public class PrintTask extends Thread {
	String name;

	public PrintTask(String name) {
		this.name = name;
	}

	public void run() {
		for(int i=0; i<200000; i++) {
			
		}

		System.out.println(name + " 쓰레드가 시작합니다.");
	}
}
