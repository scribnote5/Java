package org.sdy.java.concept.thread.demon;

/**
 * <pre>
 * [데몬 스레드]
 * 	주 스레드의 작업을 돕는 보조적인 역할을 하는 쓰레드 
 *  주 스레드가 종료되면 데몬 스레드는 강제적으로 종료
 * 
 * </pre>
 * @author scribnote5
 *
 */
public class AutoSaveThread extends Thread {
    
    public void save() {
        System.out.println("작업 내용 저장함");
    }
    
    public void run() {
        while (true) {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                break;
            }
            save();
        }
    }
}
 