package org.sdy.java.concept.thread.basic;

/**
 * Thread 테스트
 * 
 * @author scribnote5
 *
 */
public class ThreadTest {

	public static void main(String[] args) {
		/*
		 * extends Thread
		 */
		// Thread 클래스로부터 생성
		PrintTask thread1 = new PrintTask();
		thread1.setName("쓰레드 이름 변경1");
		thread1.start();

		// 익명 객체 이용
		Thread thread2 = new Thread() {
			@Override
			public void run() {
				Thread.currentThread().setName("쓰레드 이름 변경2");
				System.out.println("extends Thread 쓰레드가 시작합니다.");
			}
		};
		thread2.start();

		// Thread 이름 출력
		System.out.println(thread1.getName());
		System.out.println(thread2.getName());

		/*
		 * implements Runnable
		 */
		// Thread 클래스로 부터 직접 생성
		Runnable printTask2 = new PrintTask2();
		Thread thread3 = new Thread(printTask2);
		// 다음과 같이 사용가능
		// Thread thread1 = new Thread( new PrintTask());
		thread3.start();

		// 익명 객체 이용
		Thread thread4 = new Thread(new Runnable() {
			@Override
			public void run() {
				System.out.println("implements Runnable 쓰레드가 시작합니다.");
			}
		});
		thread4.start();

	}
}
