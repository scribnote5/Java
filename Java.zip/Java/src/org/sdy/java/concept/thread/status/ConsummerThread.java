package org.sdy.java.concept.thread.status;

public class ConsummerThread extends Thread{
	private DataBox dataBox;

	public ConsummerThread(DataBox dataBox) {
		this.dataBox = dataBox;
	}
	
	public void run() {
		for(int i=0; i<3; i++) {
			String data = dataBox.getData();
		}
	}
	
	
}
