package org.sdy.java.concept.thread.pool;

import java.util.concurrent.*;

/**
 * 작업 완료 순으로 통보 테스트
 * 
 * <pre>
 * 	작업 요청 순서대로 작업 처리가 완료되지는 않음
 *  작업 양과 스케줄링에 따라서 먼저 요청한 작업이 나중에 완료되는 경우가 발생
 *  CompletionService를 이용해서 쓰레드 풀에서 작업 처리가 완료된거 것만 통보받을 수 있음
 * </pre>
 * 
 * @author scribnote5
 *
 */
public class PriorityThreadTest {

	public static void main(String[] args) {
		// CPU 코어의 수만큼 최대 스레드를 사용하는 스레드풀을 생성
		ExecutorService executorService = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
		// CompletionService 생성
		CompletionService<Integer> completionService = new ExecutorCompletionService<>(executorService);

		System.out.println("처리 요청");

		// 쓰레드 풀 작업 처리 요청
		for (int i = 0; i < 3; i++) {
			completionService.submit(new Callable<Integer>() {
				public Integer call() throws Exception {
					int sum = 0;

					for (int i = 1; i <= 10; i++) {
						sum += i;
					}

					return sum;
				}
			});
		}

		System.out.println("처리 완료된 작업 확인");
		// 쓰레드 풀에서 쓰레드 실행하도록 함
		executorService.submit(new Runnable() {
			public void run() {
				while (true) {
					try {
						// 완료된 작업 가져오기
						Future<Integer> future = completionService.take();
						int value = future.get();
						System.out.println("처리 결과: " + value);
					} catch (Exception e) {
						break;
					}
				}
			}
		});

		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
		}
		executorService.shutdownNow();
	}
}
