package org.sdy.java.concept.thread.group;

public class WorkThread extends Thread {
	public WorkThread(ThreadGroup tg, String threadName) {
		super(tg, threadName);
	}

	public void run() {
		while (true) {
			try {
				Thread.sleep(1000);
			} catch (Exception e) {
				System.out.println(getName() + " interrupted");
				break;
			}
		}

		System.out.println(getName() + " 종료됨");

	}
}
