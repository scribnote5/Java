package org.sdy.java.concept.polymorphism.parameter;

public interface Vehicle {
	public void run();
}