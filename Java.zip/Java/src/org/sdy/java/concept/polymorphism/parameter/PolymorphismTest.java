package org.sdy.java.concept.polymorphism.parameter;

/**
 * 다형성 매개변수 테스트
 * 
 * @author scrib
 *
 */
public class PolymorphismTest {
	public static void main(String[] args) {
		Driver driver = new Driver();
		Bus bus = new Bus();
		Taxi taxi = new Taxi();

		// 매개변수의 객체에 따라서 다형성 구현  
		driver.drive(bus);
		driver.drive(taxi);
	}
}
