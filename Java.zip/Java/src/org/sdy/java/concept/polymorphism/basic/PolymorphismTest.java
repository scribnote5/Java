package org.sdy.java.concept.polymorphism.basic;

import java.util.*;

/**
 * 다형성 테스트
 * 
 * @author scrib
 *
 */
public class PolymorphismTest {

	public static void main(String[] args) {
		// DatabaseLoad 인터페이스를 이용해서 프로그램 개발
		// 처음 구현한 클래스 MysqlLoad대신 다른 데이터베이스 사용 필요
		// 이런 경우 CubridLoad 인터페이스를 만들고 단 한줄만 수정 후 프로그램 재실행 가능
//		 DatabaseLoadService databaseLoad = new MysqlLoad();
//		 DatabaseLoadService databaseLoad = new CubridLoad();

		// 배열 형태 객체관리
		 DatabaseLoadService[] databaseLoad = new DatabaseLoadService[2];
		 databaseLoad[0] = new MysqlLoad();
		 databaseLoad[1] = new CubridLoad();

		// List 형태 객체관리
//		 List<DatabaseLoadService> databaseLoad = new
//		 ArrayList<DatabaseLoadService>();
//		 databaseLoad.add(new MysqlLoad());
//		 databaseLoad.add(new CubridLoad());

	}
}
