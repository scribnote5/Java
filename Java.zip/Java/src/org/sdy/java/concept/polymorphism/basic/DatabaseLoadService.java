package org.sdy.java.concept.polymorphism.basic;

public interface DatabaseLoadService {
	void load();
}
