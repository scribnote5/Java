package org.sdy.java.concept.polymorphism.basic;

public class MysqlLoad implements DatabaseLoadService {

	MysqlLoad() {
		load();
	}
	
	@Override
	public void load() {
		System.out.println("MySQL Load");
		
	}

}
