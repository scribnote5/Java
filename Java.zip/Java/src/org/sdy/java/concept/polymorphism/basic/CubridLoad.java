package org.sdy.java.concept.polymorphism.basic;

public class CubridLoad implements DatabaseLoadService {

	CubridLoad() {
		load();
	}
	
	@Override
	public void load() {
		System.out.println("Cubrid Load");

	}

}
