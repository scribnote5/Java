package org.sdy.java.concept.annotation;

public class PrintAnnotationService {
	@PrintAnnotation
	public void method1() {
		System.out.println("메소드 실행1");
	}

	@PrintAnnotation("*")
	public void method2() {
		System.out.println("메소드 실행2");
	}	
	
	@PrintAnnotation(value="#", number=20)
	public void method3() {
		System.out.println("메소드 실행3");
	}
	
	public void method4() {
		System.out.println("메소드 실행4");
	}	
}
