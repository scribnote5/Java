package org.sdy.java.concept.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 어노테이션
 * 
 * <pre>
 *	[Target : 범위]
 *	TYPE : Class, Interface, Annotation, Enum
 *	FIELD
 *	METHOD
 *	PARAMETER : 메소드의 인자
 *	CONSTRUCTOR
 *	LOCAL_VARIABLE : 메소드 내부 변수
 *	ANNOTATION_TYPE : Annotation
 *	PACKAGE : 패키지
 *
 * 	[Retention : 용도]
 *	SOURCE : 컴파일러가 사용하고 클래스 파일 안에 포함되지 않음 (단순 주석용, 컴파일러용)
 *	CLASS : 컴파일시 클래스 파일 안에 포함되나 VM에서 무시함
 *	RUNTIME : 컴파일시 포함되고 VM에서 인식함
 * </pre>
 * 
 * @author scrib
 *
 */

@Target({ ElementType.TYPE, ElementType.FIELD, ElementType.METHOD })
@Retention(RetentionPolicy.RUNTIME)
public @interface PrintAnnotation {
	String value() default "-";
	int number() default 10;
}
