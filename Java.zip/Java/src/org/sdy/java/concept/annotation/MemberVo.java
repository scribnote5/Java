package org.sdy.java.concept.annotation;

import java.util.*;

import lombok.*;

/**
 * equals, hashCode, toString, clone
 * 
 * <pre>
 * 	equals() : 객체가 저장하고 있는 데이터의 동일함 비교 
 * 	hashCode() : 객체마다 다른 값을 가지는 고유값
 * 	hashCode()와 equals()를 오버라이딩해 객체의 동등 비교
 * 
 * 	thin clone : 필드 값 복사, 참조 타입인 경우 객체 주소 복사 
 * 	deep clone : 필드 값 복사, 참조 타입인 경우 객체 자체를 복사
 * </pre>
 * 
 * @author scrib
 *
 */

@Data
public class MemberVo implements Cloneable {
	private String id;
	private String pw;
	private List<String> buyList = new ArrayList<String>();
	
	public MemberVo(String id, String pw, List<String> buyList) {
		this.id = id;
		this.pw = pw;
		this.buyList = buyList;
	}

	@Override
	public String toString() {
		return "MemberVo [id=" + id + ", pw=" + pw + ", buyList=" + buyList + "]";
	}

	public MemberVo() {
	}

}
