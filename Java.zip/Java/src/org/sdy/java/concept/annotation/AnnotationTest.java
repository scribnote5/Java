package org.sdy.java.concept.annotation;

import java.lang.reflect.*;

/**
 * 어노테이션 테스트 : 어노테이션이 적용된 메소드만 호출
 * 
 * <pre>
 *	메타데이터로서 컴파일 과정과 실행 과정에서 코드를 어떻게 컴파일하고 처리할지를 알려주는 정보 
 * 
 *	컴파일러에게 코드 문법 에러 체크 정보 제공
 *	소프트웨어 개발 툴이 빌드나 배치시 코드를 자동으로 생성하도록 정보 제공
 *	실행시 특정 기능을 실행하도록 정보 제공
 *	자동으로 XML 설정 파일을 생성하거나 베포를 위해 JAR 압축 파일을 생성하는데 사용
 *	클래스 역할 정의
 * </pre>
 * 
 * 클래스, 리플렉션 
 *  
 * <pre>
 * 	클래스 객체를 통하여 클래스의 생성자, 필드, 메소드 정보를 알수 있음 
 * </pre>
 * 
 * @author scrib
 *
 */
public class AnnotationTest {

	public static void main(String[] args) {
		// PrintAnnotationService에서 선언된 메소드 얻기
		Method[] declaredMethods = PrintAnnotationService.class.getDeclaredMethods();

		for (Method method : declaredMethods) {
			// 메소드가 어노테이션이 적용되었는지 여부
			if (method.isAnnotationPresent(PrintAnnotation.class)) {
				// 지정한 어노테이션이 적용되면 어노테이션 반환
				PrintAnnotation printAnnotation = method.getAnnotation(PrintAnnotation.class);
				System.out.println("[" + method.getName() + "] ");

				for (int i = 0; i < printAnnotation.number(); i++) {
					System.out.print(printAnnotation.value());
				}
				System.out.println();

				try {
					// 메소드 호출 => 출력문 출력
					method.invoke(new PrintAnnotationService());
				} catch (Exception e) { }
				System.out.println();
			}
		}
		
		try {
			// 클래스 객체를 얻는 방법
			MemberVo member = new MemberVo();
			Class clazz1 = member.getClass();
			Class clazz2 = Class.forName("org.sdy.spring.concept.annotation.MemberVo");
			
			System.out.println(clazz1.getName());
			System.out.println(clazz1.getSimpleName());
			System.out.println(clazz1.getPackage().getName());
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}
}