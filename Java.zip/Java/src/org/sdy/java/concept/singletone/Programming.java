package org.sdy.java.concept.singletone;

public class Programming {
	private static Programming programming = new Programming();
	
	static Programming getInstance() {
		return programming;
	}
}