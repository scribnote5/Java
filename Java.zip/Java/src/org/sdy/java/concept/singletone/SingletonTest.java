package org.sdy.java.concept.singletone;

/**
 * 싱글톤 테스트
 * 
 * <pre>
 * 	단 하나의 객체만 만들어지도록 보장
 * </pre>
 * 
 * @author scrib
 *
 */
public class SingletonTest {

	public static void main(String[] args) {
		Programming programming1 = Programming.getInstance();
		Programming programming2 = Programming.getInstance();

		// 서로 같은 객체
		System.out.println(programming1);
		System.out.println(programming2);
		
	}
}