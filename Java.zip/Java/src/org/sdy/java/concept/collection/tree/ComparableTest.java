package org.sdy.java.concept.collection.tree;

import java.util.*;

/**
 * Comparable 테스트
 * 
 * <pre>
 * 	TreeSet, TreeMap 키는 오름차순으로 저장
 *  Integer, Double, String은 정렬을 위해 java.lang.Comparable 인터페이스 구현
 *  
 *  사용자 정의 클래스도 Comparable 구현시 자동정렬 가능  
 *  또는
 *  TreeSet 또는 TreeMap 생성자의 파라미터로 Comparator를 제공하면 Comparable 비구현 객체도 정렬 가능
 * </pre>
 * 
 * @author scribnote5
 *
 */
public class ComparableTest {

	public static void main(String[] args) {

		TreeSet<Person> treeSet = new TreeSet<Person>();
		treeSet.add(new Person("Jackie", 44));
		treeSet.add(new Person("Jolie", 24));
		treeSet.add(new Person("Mike", 32));

		Iterator<Person> it = treeSet.iterator();
		// 오름차순 정렬
		while (it.hasNext()) {
			Person person = it.next();
			System.out.println(person.getName() + " : " + person.getAge());
		}
		
		System.out.println();
		
		
		// 비구현 객체 정렬
		TreeSet<Person> treeSet2 = new TreeSet<Person>(new DescComparator());
		treeSet2.add(new Person("Jackie", 44));
		treeSet2.add(new Person("Jolie", 24));
		treeSet2.add(new Person("Mike", 32));

		Iterator<Person> it2 = treeSet2.iterator();
		// 내림차순 정렬
		while (it2.hasNext()) {
			Person person = it2.next();
			System.out.println(person.getName() + " : " + person.getAge());
		}
		
	}

}
