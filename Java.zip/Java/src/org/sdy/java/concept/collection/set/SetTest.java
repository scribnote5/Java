package org.sdy.java.concept.collection.set;

import java.util.*;

/**
 * Set 테스트
 * 
 * <pre>
 * 	저장 순서 유지 안됨
 *  중복 저장 불가
 * </pre>
 * 
 * @author scribnote5
 *
 */
public class SetTest {

	public static void main(String[] args) {
		Set<String> set = new HashSet<String>();

		set.add("Java");
		set.add("C");
		set.add("C#");
		set.add("SQL");
		set.add("Phythoon");

		int size = set.size();
		System.out.println("총 객체 수: " + size);

		Iterator<String> iterator = set.iterator();

		while (iterator.hasNext()) {
			String elem = iterator.next();

			System.out.println("\t" + elem);
		}

		set.remove("C#");
		set.remove("Phythoon");

		System.out.println("총 객체 수: " + set.size());

		iterator = set.iterator();

		while (iterator.hasNext()) {
			String elem = iterator.next();

			System.out.println("\t" + elem);
		}

		set.clear();
		System.out.println("HashSet 비어있는 여부 : " + set.isEmpty());

		Set<MemberVo> set2 = new HashSet<>();

		// equals, hashCode 오버라이딩하여서 이름이 같은 경우 같은 객체로 판별
		set2.add(new MemberVo("Jackie", 22));
		set2.add(new MemberVo("Jackie", 25));
		set2.add(new MemberVo("Jolie", 29));
		set2.add(new MemberVo("Hong", 24));
		set2.add(new MemberVo("Andy", 32));

		System.out.println("총 객체 수: " + set2.size());

		Iterator<MemberVo> it = set2.iterator();

		while (it.hasNext()) {
			MemberVo memberVo = it.next();
			System.out.println("\t" + memberVo.name + " - " + memberVo.age);
		}
	}

}
