package org.sdy.java.concept.collection.list;

import java.util.*;

/**
 * 리스트 테스트
 * 
 * <pre>
 * [특징]
 *  객체를 인덱스로 관리하기 때문에 객체를 저장하면 자동 인덱스 부여
 *  객체 자체를 저장하지 않고 객체 주소를 참조
 *  순서를 유지하고 저장
 *  중복 저장 가능
 *  
 * [ArrayList]
 *  간 인덱스의 객체가 제거되면 뒤 객체의 인덱스는 1씩 앞당겨짐
 *   => 순차적으로 객체 추가 삭제하면 유리
 *   
 * [LinkedList]
 *  특정 인덱스의 객체 제거하면 앞뒤 링크만 변경되고 나머지 링크는 변경되지 않음
 *   => 객체 추가와 삭제가 많으면 유리
 *       
 * </pre>
 * 
 * @author scribnote5
 *
 */
public class ListTest {

	public static void main(String[] args) {
		// ArrayList : 중간 인덱스의 객체가 제거되면 뒤 객체의 인덱스는 1씩 앞당겨짐
		List<String> list = new ArrayList<>();
		list.add("Java");
		list.add("C");
		list.add("C#");
		list.add("SQL");
		list.add("Phythoon");
		list.add("Rust");
		list.add("Kotlin");

		int size = list.size();
		System.out.println("총 객체 수: " + size);
		System.out.println();

		System.out.println("2 : " + list.get(2));
		System.out.println();

		// 인덱스를 사용한 for문
		for (int i = 0; i < list.size(); i++) {
			String str = list.get(i);
			System.out.println(i + " : " + str);
		}

		System.out.println();
		list.remove(2);
		list.remove(2);
		list.remove("Kotlin");

		// 고정된 객체들로 구성된 List 생성
		List<String> list2 = Arrays.asList("sdy", "kyg", "ybh");
		// foreach문 사용 
        for (String name : list2) {
            System.out.println(name);
        }
        
        

	}

}
