package org.sdy.java.concept.collection.tree;

import java.util.*;

// Comparator 구현 하여 내림차순 제공
public class DescComparator implements Comparator<Person> {

	@Override
	public int compare(Person o1, Person o2) {
		if(o1.getAge() < o2.getAge()) return 1;
		else if(o1.getAge() == o2.getAge()) return 0;
		else return -1;
	}

	
}
