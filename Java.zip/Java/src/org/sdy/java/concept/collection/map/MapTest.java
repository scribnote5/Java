package org.sdy.java.concept.collection.map;

import java.util.*;

/**
 * Map 테스트
 * Properties는 util 패키지 참고
 * 
 * <pre>
 *  키(key)와 값(value)으로 구성된 객체를 저장하는 구조
 *  키는 중복 저장 불가
 *  기존에 저장된 키와 동일한 키로 값을 저장하면 기존 값은 없어지고 새로운 값으로 대치
 * </pre>
 * 
 * @author scribnote5
 *
 */
public class MapTest {

	public static void main(String[] args) {
		Map<StudentVo, Integer> map = new HashMap<>();

		map.put(new StudentVo(1, "sdy"), 100);
		map.put(new StudentVo(2, "kyg"), 100);
		map.put(new StudentVo(3, "sdy"), 100);
		map.put(new StudentVo(2, "kyg"), 50);
		map.remove(new StudentVo(2, "kyg"));

		// foreach 사용
		Set<StudentVo> keySet = map.keySet();
		for (StudentVo studentVo : keySet) {
			int value = map.get(studentVo);
			System.out.println(studentVo + " : " + value);
		}

		// iterator 사용
		// Set<StudentVo> keySet = map.keySet();
		// Iterator<StudentVo> it = keySet.iterator();
		//
		// while (it.hasNext()) {
		// StudentVo key = it.next();
		// Integer value = map.get(key);
		// System.out.println(key + " : " + value);
		// }

		System.out.println("총 객체 수: " + map.size());
		
		map.clear();
		System.out.println("총 객체 수: " + map.size());
	}

}
