package org.sdy.java.concept.collection.tree;

import java.util.*;

/**
 * 트리 테스트
 * 
 * <pre>
 *  검색 기능을 강화시킨 이진트리를 이용해서 트리 구조를 가지면서 객체 저장
 * 
 * 	[TreeMap]
 * 	TreeMap에 객체를 저장하면 자동으로 정렬 
 *  기본적으로 부모 키값과 비교해서 키 값이 낮은 것은 왼쪽 노드에, 키 값이 높은 것은 오른쪽 노드에 Map.Entry에 저장
 * 
 * </pre>
 * 
 * 
 * @author scribnote5
 *
 */

public class TreeMapTest {

	public static void main(String[] args) {

		TreeMap<Integer, String> treeMap = new TreeMap<Integer, String>();

		treeMap.put(new Integer(90), "Jack");
		treeMap.put(new Integer(77), "Mike");
		treeMap.put(new Integer(82), "Jolie");
		treeMap.put(new Integer(93), "Sminoph");
		treeMap.put(new Integer(67), "Neil");
		treeMap.put(new Integer(55), "Max");

		Map.Entry<Integer, String> entry = null;

		entry = treeMap.firstEntry();
		// 가장 낮은 Map.Entry를 꺼내고 컬렉션 제거
		// entry = treeMap.pollFirstEntry();
		System.out.println("가장 낮은 점수: " + entry.getKey() + "-" + entry.getValue());

		// 가장 높은 Map.Entry를 꺼내고 컬렉션 제거
		// entry = treeMap.pollLastEntry();
		entry = treeMap.lastEntry();
		System.out.println("가장 높은 점수: " + entry.getKey() + "-" + entry.getValue());

		entry = treeMap.lowerEntry(new Integer(95));
		System.out.println("95점 아래 점수: " + entry.getKey() + "-" + entry.getValue());

		System.out.println();

		while (!treeMap.isEmpty()) {
			// 가장 낮은 Map.Entry를 꺼내고 컬렉션 제거
			entry = treeMap.pollFirstEntry();
			System.out.println(entry.getKey() + "-" + entry.getValue() + " (남은 객체 수: " + treeMap.size() + ")");
		}

		TreeMap<Integer, String> treeMap2 = new TreeMap<Integer, String>();

		treeMap2.put(new Integer(100), "Jolie");
		treeMap2.put(new Integer(95), "SAN E");
		treeMap2.put(new Integer(81), "ZICO");
		treeMap2.put(new Integer(79), "MICRODOT");
		treeMap2.put(new Integer(71), "BASICK");
		treeMap2.put(new Integer(67), "MINO");
		treeMap2.put(new Integer(52), "Black Nut");

		// 내림차순
		NavigableMap<Integer, String> descendingMap = treeMap2.descendingMap();
		Set<Map.Entry<Integer, String>> descendingEntrySet = descendingMap.entrySet();

		for (Map.Entry<Integer, String> entry2 : descendingEntrySet) {
			System.out.println(entry2.getKey() + "-" + entry2.getValue() + " ");
		}
		System.out.println();

		// 오름차순 : 내림차순으로 정렬된 Map.Entry 반환
		NavigableMap<Integer, String> ascendingMap = descendingMap.descendingMap();
		Set<Map.Entry<Integer, String>> ascendingEntrySet = ascendingMap.entrySet();

		for (Map.Entry<Integer, String> entry2 : ascendingEntrySet) {
			System.out.println(entry2.getKey() + "-" + entry2.getValue() + " ");
		}

	}
}
