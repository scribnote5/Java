package org.sdy.java.concept.collection.tree;

import java.util.*;

/**
 * 트리 테스트
 * 
 * <pre>
 *  검색 기능을 강화시킨 이진트리를 이용해서 트리 구조를 가지면서 객체 저장
 * 
 *  [TreeSet]
 *  하나의 노드는 노드 값인 value와 왼쪽과 오른쪽 자식 노드를 참조하기 위한 두 개의 변수로 구성
 *  TreeSet에 객체를 저장하면 자동으로 정렬되는데 부모값과 비교해서 낮은 것은 왼쪽 노드에, 높은 것은 오른쪽 노드에 저장
 * 
 * </pre>
 * 
 * 
 * @author scribnote5
 *
 */

public class TreeSetTest {

	public static void main(String[] args) {
		// TreeSet
		TreeSet<Integer> treeSet = new TreeSet<Integer>();

		for (int i = 0; i < 5; i++) {
			treeSet.add(new Integer((int) Math.round(Math.random() * 50 + 50)));
		}

		Integer score = null;

		score = treeSet.first();
		// 가장 낮은 객체를 꺼내고 컬렉션 제거
		// score = treeSet.pollFirst();
		System.out.println("가장 낮은 점수: " + score);

		score = treeSet.last();
		// 가장 낮은 객체를 꺼내고 컬렉션 제거
		// score = treeSet.pollLast();
		System.out.println("가장 높은 점수: " + score);

		score = treeSet.lower(new Integer(90));
		System.out.println("90점 아래 점수: " + score);

		score = treeSet.higher(new Integer(90));
		System.out.println("90점 위 점수: " + score);

		// Tree안 점수 내림차순
		NavigableSet<Integer> descendingSet = treeSet.descendingSet();
		for (Integer score2 : descendingSet) {
			System.out.print(score2 + " ");
		}
		System.out.println();

		// Tree안 점수 오름차순
		NavigableSet<Integer> ascendingSet = descendingSet.descendingSet();
		for (Integer score2 : ascendingSet) {
			System.out.print(score2 + " ");
		}
		System.out.println();

		TreeSet<String> words = new TreeSet<String>();

		words.add("apple");
		words.add("banana");
		words.add("china");
		words.add("cypher");
		words.add("description");
		words.add("ever");
		words.add("guess");
		words.add("cherry");

		System.out.println("[c~f 사이의 단어 검색]");
		// c <= 검색 단어 <= f 
		NavigableSet<String> rangeSet = words.subSet("c", true, "f", true);

		for (String word : rangeSet) {
			System.out.println(word);
		}

	}

}
