package org.sdy.java.concept.collection.map;

public class StudentVo {
	public int sno;
	public String name;

	public StudentVo(int sno, String name) {
		this.sno = sno;
		this.name = name;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + sno;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StudentVo other = (StudentVo) obj;
		if (sno != other.sno)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "StudentVo [sno=" + sno + ", name=" + name + "]";
	}
	
	

}
