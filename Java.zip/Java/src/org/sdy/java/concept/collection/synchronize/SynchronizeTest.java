package org.sdy.java.concept.collection.synchronize;

import java.util.*;
import java.util.concurrent.*;

/**
 * 동기화된 컬렉션 테스트
 * 
 * <pre>
 *  Vector, Hashtable는 기본적으로 동기화된 컬렉션
 *  ArrayList, HashSet, HashMap 동기화 메소드 제공
 * </pre>
 * 
 * @author scribnote5
 *
 */
public class SynchronizeTest {

	public static void main(String[] args) {
		// 동기화된 컬렉션 : 멀티 쓰레드 환경에서 안전
		List<String> list = Collections.synchronizedList(new ArrayList<String>());
		Set<String> set = Collections.synchronizedSet(new HashSet<String>());
		Map<Integer, String> map = Collections.synchronizedMap(new HashMap<Integer, String>());

		// 병렬 처리를 위한 컬렉션 : 멀티 쓰레드 환경에서 쓰레드에 안전하면서 잠금없이 병렬적으로 처리하는 특별한 컬렉션
		Map<Integer, String> map2 = new ConcurrentHashMap<Integer, String>();
		Queue<String> queue = new ConcurrentLinkedQueue<String>();
	}

}
