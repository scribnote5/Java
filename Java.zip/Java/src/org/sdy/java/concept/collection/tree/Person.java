package org.sdy.java.concept.collection.tree;

import lombok.*;

@Data
// 나이를 기준으로 Person 객체를 오름차순으로 정렬하기 위해 Comparable 인터페이스 구현
public class Person implements Comparable<Person> {
	private String name;
	private int age;

	public Person(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}

	@Override
	// 주어진 객체와 같으면 0
	// 주어진 객체보다 적으면 음수
	// 주어진 객체보다 크면 양수
	public int compareTo(Person person) {
		if (age < person.age)
			return -1;
		else if (age == person.age)
			return 0;
		else
			return 1;
	}
}
