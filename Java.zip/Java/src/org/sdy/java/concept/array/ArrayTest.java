package org.sdy.java.concept.array;

import java.util.*;

/**
 * 배열 테스트
 * 
 * <pre>
 * 	한 번 생성된 배열은 길이를 늘리거나 줄일 수 없음
 * </pre>
 * 
 * @author scrib
 *
 */
public class ArrayTest {

	public static void main(String[] args) {
		// 값 목록으로 배열 생성
		int[] arr1 = { 1, 2, 3 };
		int[] arr2 = new int[] { 1, 2, 3 };

		// new 연산자로 배열 생성
		int[] arr3 = new int[3];
		arr3[0] = 1;
		arr3[1] = 2;
		arr3[2] = 3;

		// 배열길이
		System.out.println("배열 3의 길이 : " + arr3.length);

		// 다차원 배열
		// 값 목록으로 배열 생성
		int[][] arr4 = { { 1, 2, 3 }, { 1, 2, 3 } };
		int[][] arr5 = new int[][] { { 1, 2, 3 }, { 1, 2, 3 } };

		// 다차원 배열
		// new 연산자로 배열 생성
		int[][] arr6 = new int[2][3];
		arr6[0][0] = 1;
		arr6[0][1] = 2;
		arr6[0][2] = 3;
		arr6[1][0] = 1;
		arr6[1][1] = 2;
		arr6[1][2] = 3;

		// 다차원 배열 출력방법
		for (int[] num : arr6) {
			for (int num2 : num) {
				System.out.print(num2 + " ");
			}
			System.out.println();
		}

		// 배열복사
		// Arrays.copyOf(원본배열, 원본시작 인덱스, 타겟배열, 타겟시작 인덱스, 복사 개수);
		// int[] arr1Copy = Arrays.copyOf(arr1, arr1.length);

	}

}
