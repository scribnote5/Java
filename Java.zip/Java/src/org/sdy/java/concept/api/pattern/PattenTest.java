package org.sdy.java.concept.api.pattern;

import java.util.regex.*;

/**
 * 정규식 테스트
 * 
 * <pre>
 * 자세한 참고 : 이것이 자바다 p.517 
 *
 * [특수문자 모음집]
 * 	* : [*]
 * 	+ : [+]
 * 	$ : [$] 
 * 	| : [|]
 * 	? : [?]
 * 	( : \\(
 * 	) : \\)
 * 	{ : \\{
 * 	} : \\}
 * 	^ : \\^
 * 	[ : \\[
 * 	] : \\]
 * 	" : \"
 * 
 * [별도의 처리없는 부호들]
 * 	! # % & @ ` : ; - . < > , ~ , /'
 * </pre>
 * 
 * @author scribnote5
 *
 */

public class PattenTest {

	public static void main(String[] args) {
		// 한글
		String koreanRegExp = "[ㄱ-ㅎㅏ-ㅣ가-힣]";
		// 특수문자(! # % & @ ` : ; - . < > , ~ '제외)
		String specialLetters = "[?][$]\\(\\)\\{\\}[*][+]\\^[|]\\[\\]";

		// 이메일 정규식
		String emailRegExp = "\\w+@\\w+\\.\\w+(\\.\\w+)?";
		// 휴대폰 정규식
		String phoneRegExp = "\\d{3}-\\d{3,4}-\\d{4}";
		// 휴대폰에 특수문자 제거 정규식
		String phoneReplaceRegExp = "[ㄱ-ㅎㅏ-ㅣ가-힣[?][$]\\\\(\\\\)\\\\{\\\\}[*][+]\\\\^[|]\\\\[\\\\]]";
		// 사칙연산 정규식
		String operationRegExp = "[+] |-| [*] | /";
		
		
		System.out.println(Pattern.matches(emailRegExp, "scribnote5@gmail.com"));
		System.out.println(Pattern.matches(phoneRegExp, "010-8345-0755(본인)"));
		System.out.println("010-8345-0755(본인)".replaceAll(phoneReplaceRegExp, ""));
		System.out.println("3 + 4 - 2 * 3 / 2".replaceAll(operationRegExp, " P "));
	}

}
