package org.sdy.java.concept.api.system;

import java.security.*;

/**
 * System 클래스 테스트
 * 
 * @author scribnote5
 *
 */

public class SystemTest {

	public static void main(String[] args) {
		// 보안 관리자 설정
		System.setSecurityManager(new SecurityManager() {

			// System.exit() 실행시 checkExit 메소드가 자동 호출
			@Override
			public void checkExit(int status) {
				System.out.println(status);
				// 0이 아니면 모두 예외처리
				if (status != 0) {
					throw new SecurityException();
				}
			}

			@Override
			public void checkPermission(Permission perm) {
				System.out.print("perm" + perm + " : ");
				// 아래의 코드를 주석해야만 exception이 발생하지 않으며 왜 해야하는지 이유를 모르겠음
				// 참고 : http://blog.daum.net/badog/4458055
				// super.checkPermission(perm);
			}

		});

		// 시스템 프로퍼티 읽기
		System.out.println(System.getProperty("java.version"));
		System.out.println(System.getProperty("java.home"));
		System.out.println(System.getProperty("os.name"));
		System.out.println(System.getProperty("file.separator"));
		System.out.println(System.getProperty("user.name"));
		System.out.println(System.getProperty("user.home"));
		System.out.println(System.getProperty("user.dir"));

		// 환경변수 읽기
		System.out.println(System.getenv("JAVA_HOME"));

		// 프로그램 종료
		// 정상종료 : 0
		// 비정상 종료 : 0이외 값
		System.exit(5); // 5인 경우 exception 발생
		System.exit(0);

		// JVM에 가능한 빠리 쓰레기 수집하라고 요청
		// 메모리가 열악하지 않은 환경이라면 사용할 일이 없음
		System.gc();

	}

}