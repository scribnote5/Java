package org.sdy.java.concept.api.object;

import java.util.*;

/**
 * Object 클래스 테스트
 * 
 * @author scribnote5
 *
 */
public class ObjectTest {

	public static void main(String[] args) {
		MemberVo member1 = new MemberVo("sdy", "123", Arrays.asList("가방", "책"));
		MemberVo member2 = new MemberVo("sdy", "123", Arrays.asList("컵", "지우개"));

		// id, pw가 같은 member1과 member2는 같은 객체
		System.out.println(member1.equals(member2));
		System.out.println(member1.hashCode() == member2.hashCode());

		// 복제
		member2 = member1.thinClone();
		member2 = member1.deepClone();

		System.out.println(member1);
		System.out.println(member2);
		System.out.println();
		
		// finalize
		// 무작위로 소멸하며 메모리의 상태를 보고ㅓ 일부만 소멸
		Counter counter = null;
		for(int i=1; i<50; i++) {
			counter = new Counter(i);
			counter =null;
			System.gc();
		}
		
	}

}
