package org.sdy.java.concept.api.objects;

import java.util.*;
/**
 * Objects 클래스 테스트
 * 
 * @author scribnote5
 *
 */
public class ObjectsTest {

	public static void main(String[] args) {
		// hashCode()를 오버라이딩한 값과 Objects 클래스를 이용한 hashCode 값은 같음 
		Student student1 = new Student("홍길동", 1);
		System.out.println(student1.hashCode());
		System.out.println(Objects.hashCode(student1));
		
	}

}
