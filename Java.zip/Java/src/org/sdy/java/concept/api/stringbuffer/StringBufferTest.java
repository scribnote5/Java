package org.sdy.java.concept.api.stringbuffer;

/**
 * 
 * 스트링 버퍼 테스트
 * 
 * <pre>
 * 	문자열을 결합하는 + 연사자를 만힝 사용하면 String 객체가 들어나기에 프로그램 성능 저하
 * 	문자열을 변경하는 작업이 많은 경우 사용
 * </pre>
 * 
 * @author scrib
 *
 */

public class StringBufferTest {

	public static void main(String[] args) {
		StringBuffer sb = new StringBuffer();
		sb.append("문자열 추가");
		sb.insert(6, "!");
		sb.setCharAt(6, '~');
		sb.replace(6, 8, "##");
		sb.delete(6, 8);
		System.out.println(sb.length());
		System.out.println(sb.toString());
	}

}
