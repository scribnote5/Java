package org.sdy.java.concept.api.object;
/**
 * finalize(객체 소멸자)
 * 
 * <pre>
 * 	객체를 소멸하기 직전 마짐가으로 객체의 소멸자를 실행
 * 	마지막 사용한 자원을 닫고 싶거나 프로그램 종료시 즉시 자원해제하거나 중요한 데이터 저장시 사용
 * </pre>
 * 
 * @author scribnote5
 *
 */

public class Counter {

	private int num;

	Counter(int num) {
		this.num = num;
	}

	@Override
	protected void finalize() throws Throwable {
		System.out.println(num + "번 객체의 finalze()가 실행");
	}

}
