package org.sdy.java.concept.api.calender;

import java.text.*;
import java.util.*;

/**
 * Calender 클래스 테스트
 * 
 * @author scribnote5
 *
 */

public class CalenderTest {

	public static void main(String[] args) {
		// 형변환 
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Calendar cal = Calendar.getInstance();
		// 날짜와 시간 정보 
		System.out.println(cal.get(Calendar.YEAR));
		System.out.println(cal.get(Calendar.MONTH));
		System.out.println(cal.get(Calendar.DAY_OF_MONTH));
		System.out.println(cal.get(Calendar.DAY_OF_WEEK)); //요일
		System.out.println(cal.get(Calendar.AM_PM)); 
		System.out.println(cal.get(Calendar.HOUR));
		System.out.println(cal.get(Calendar.MINUTE));
		System.out.println(cal.get(Calendar.SECOND));
		
		// 현재 날짜 계산
		cal.setTime(new Date());
		cal.add(Calendar.YEAR, -1); // 1년을 뺌
		cal.add(Calendar.MONTH, -1); // 한달을 뺌
		cal.add(Calendar.DAY_OF_MONTH, -1); // 하루를 뺌
		cal.add(Calendar.HOUR, 1); // 시간을 더함
		cal.add(Calendar.MINUTE, 1); // 분을 더함
		cal.add(Calendar.SECOND, 1); // 초를 더함

		String nowDate = sdf.format(cal.getTime());
		System.out.println(nowDate);

		// 특정 날짜 출력
		try {
			cal.setTime(sdf.parse("2017-08-07 00:00:00"));
			String birthDate = sdf.format(cal.getTime());
			System.out.println(birthDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
