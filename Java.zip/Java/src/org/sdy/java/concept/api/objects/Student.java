package org.sdy.java.concept.api.objects;

import java.util.*;

/**
 * hash(), hashCode()
 * 
 * @author scribnote5
 *
 */
public class Student {
	String name;
	int num;

	Student(String name, int num) {
		this.name = name;
		this.num = num;
	}

	@Override
	public int hashCode() {
		// 해쉬코드를 생성
		return Objects.hash(num, name);
	}

}
