package org.sdy.java.concept.api.wrapper;

/**
 * Wrapper 클래스 테스트
 * 
 * <pre>
 * 	박싱 : 기본타입의 값을 갖는 객체를 포장 객체로 만듬
 * 	언박싱 : 포장 객체에서 기본 탑이의 값을 얻음
 *  포장 객체 값 비교 : ==, != 연산자 사용 불가하며 equals를 사용하거나 언박싱 후 비교
 * </pre>
 * 
 * @author scribnote5
 *
 */
public class WrapperTest {

	public static void main(String[] args) {
		Integer num1 = 100;
		Integer num2 = 200;
		// 언박싱
		System.out.println(num1 + 100);
		// 포장 값 비교
		System.out.println(num1 == num2);
		System.out.println(num1.equals(num2 - 100));
		// 문자 => 숫자
		System.out.println(Integer.parseInt("100"));
		System.out.println(Double.parseDouble("100.1"));
		// 숫자 => 문자
		System.out.println(Integer.toString(100));
		System.out.println(Double.toString(100.1));

	}

}
