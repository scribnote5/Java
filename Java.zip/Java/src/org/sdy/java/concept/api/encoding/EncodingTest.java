package org.sdy.java.concept.api.encoding;

import java.io.*;

/**
 * 인코딩 테스트
 * 
 * @author scrib
 *
 */

public class EncodingTest {

	public static void main(String[] args) {
		try {
			String str = new String("안녕하세요".getBytes(), "UTF-8");
			// 잘못된 인코딩 방식 : euc-kr 타입으로 읽어서 utf-8 타입으로 쓰기  
			String str2 = new String("안녕하세요".getBytes("euc-kr"), "UTF-8");
			System.out.println(str);
			System.out.println(str2);
			

		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
		
	}

}
