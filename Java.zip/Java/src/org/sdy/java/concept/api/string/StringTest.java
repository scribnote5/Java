package org.sdy.java.concept.api.string;

import java.util.*;

/**
 * String 테스트
 * 
 * @author scribnote5
 *
 */
public class StringTest {

	public static void main(String[] args) {
		String str = "Java Programming";

		// 특정 위치 문자
		System.out.println(str.charAt(3));
		
		// 문자열 찾기
		System.out.println(str.indexOf("Programming"));
		
		// 문자열 길이
		System.out.println(str.length());
		
		// 문자열 치환 : 정규식 미사용 
		System.out.println(str.replace("Java", "Phython"));
		
		// 문자열 잘라내기
		System.out.println(str.substring(0, 4)); // 0부터 3까지 출력
		System.out.println(str.substring(5));
		
		// 소문자 변경
		System.out.println(str.toLowerCase());
		
		// 대문자 변경
		System.out.println(str.toUpperCase());
		
		// 대소문자 무시 비교
		System.out.println((str.toLowerCase()).equalsIgnoreCase(str.toUpperCase()));
		
		// 문자열 앞뒤 공백 자르기
		System.out.println(str.trim());
		
		// 문자열 나누기 : split
		String[] result = str.split(" ");
		System.out.println(result[0]);
		System.out.println(result[1]);
		
		// 문자열 나누기 : StringTokenizer
		StringTokenizer st = new StringTokenizer(str, " ");
		int countTokens = st.countTokens();
		for(int i =0; i < countTokens; i++) {
			System.out.println(st.nextToken());
		}
	
		st = new StringTokenizer(str, " ");
		while(st.hasMoreTokens()) {
			System.out.println(st.nextToken());
		}

	}

}
