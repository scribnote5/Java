package org.sdy.java.concept.api.format;

import java.text.*;

/**
 * Format 클래스 테스트
 * 
 * <pre>
 *  [문자열 변환]
 *  데이터 파일 저장, 네트워크 전송, SQL 작성시 가독성 향상에 유용
 *  
 *  숫자, 날짜 변환
 *  
 * 	참고 : 이것이 자바다 p.543
 * </pre>
 * 
 * @author scribnote5
 *
 */
public class FormatTest {

	public static void main(String[] args) {
		String id = "sdy";
		String pw = "123";

		String account = "ID : {0}\nPW : {1}";
		// 다음 문자열 변환에 유용
		// String result = "ID : " + id + "\nPW : " + pw;
		String result = MessageFormat.format(account, id, pw);
		System.out.println(result);
	}

}
