package org.sdy.java.concept.api.object;

import java.util.*;

/**
 * equals, hashCode, toString, clone
 * 
 * <pre>
 * 	equals() : 객체가 저장하고 있는 데이터의 동일함 비교 
 * 	hashCode() : 객체마다 다른 값을 가지는 고유값
 * 	hashCode()와 equals()를 오버라이딩해 객체의 동등 비교
 * 
 *  thin clone : 필드 값 복사, 참조 타입인 경우 객체 주소 복사 
 *  deep clone : 필드 값 복사, 참조 타입인 경우 객체 자체를 복사
 * </pre>
 * 
 * @author scrib
 *
 */
public class MemberVo implements Cloneable {
	private String id;
	private String pw;
	private List<String> buyList = new ArrayList<String>();

	public MemberVo(String id, String pw, List<String> buyList) {
		super();
		this.id = id;
		this.pw = pw;
		this.buyList = buyList;
	}

	@Override
	// id, pw가 같은 경우 같은 객체로 판별
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((pw == null) ? 0 : pw.hashCode());
		return result;
	}

	@Override
	// id, pw가 같은 경우 같은 객체로 판별
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MemberVo other = (MemberVo) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (pw == null) {
			if (other.pw != null)
				return false;
		} else if (!pw.equals(other.pw))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "MemberVo [id=" + id + ", pw=" + pw + ", buyList=" + buyList + "]";
	}

	// thin clone : 얕은 복제
	public MemberVo thinClone() {
		MemberVo clone = null;

		try {
			clone = (MemberVo) clone();
		} catch (Exception e) {

		}
		return clone;
	}

	// deep clone : 깊은 복제
	public MemberVo deepClone() {
		MemberVo clone = null;

		try {
			// 먼저 얕은 복사를 실행
			clone = (MemberVo) clone();
			
			for (String item : buyList) {
				clone.buyList.add(item);
			}
		} catch (Exception e) {

		}
		return clone;
	}

}
