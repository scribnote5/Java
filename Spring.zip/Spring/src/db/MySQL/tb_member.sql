CREATE TABLE tb_member (
  userId varchar(32) PRIMARY KEY ,
  userPw varchar(32),
  userName varchar(32),
  email varchar(32),
  regDate timestamp default now(),
  updateDate timestamp default now()
);
