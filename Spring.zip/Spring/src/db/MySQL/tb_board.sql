create table tb_board (
	boardNum int auto_increment primary key,
    title varchar(200),
    content text,
    writer varchar(50),
    regDate timestamp default now(),
    updateDate timestamp default now(),
    viewCnt int default 0
);