package org.sdy.spring.board.dao;

import java.util.*;

import org.apache.ibatis.annotations.*;
import org.sdy.spring.board.vo.*;

@Mapper
public interface BoardDAO {
	public List<BoardVO> selectList(BoardVO vo) throws Exception;
	public BoardVO select(BoardVO vo) throws Exception;
	public void insert(BoardVO vo) throws Exception;
	public void update(BoardVO vo) throws Exception;
	public void delete(BoardVO vo) throws Exception;
}
