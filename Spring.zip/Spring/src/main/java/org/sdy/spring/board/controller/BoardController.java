package org.sdy.spring.board.controller;

import java.util.*;

import javax.inject.*;

import org.sdy.spring.board.service.*;
import org.sdy.spring.board.vo.*;
import org.slf4j.*;
import org.springframework.stereotype.*;
import org.springframework.ui.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.*;


@Controller
public class BoardController {

	//	@Resource(name = "BoardService")
	@Inject
	private BoardService boardService;

	// import : org.slf4j.* 
	private static final Logger logger = LoggerFactory.getLogger(BoardController.class);

	/**
	 * 목록 조회
	 * @param boardVO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/board/boardList.do")
	public String boardList(@ModelAttribute BoardVO boardVO, Model model) throws Exception {
		logger.info("!!!");
		List<BoardVO> boardList = boardService.selectList(boardVO);
		model.addAttribute("boardList", boardList);
		
		return "/board/boardList";
	}

	/**
	 * 등록 보기
	 * @param boardVO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/board/boardInsertView.do")
	public String boardInsertView(@ModelAttribute BoardVO boardVO) throws Exception {

		return "/board/boardRegister";
	}

	/**
	 * 등록
	 * @param boardVO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/board/boardInsert.do")
	public String boardInsert(BoardVO boardVO, RedirectAttributes attrs, Model model) throws Exception {

		boardVO = boardService.insert(boardVO);
		System.err.println(boardVO);
		attrs.addFlashAttribute("boardVO", boardVO);
		
		return "redirect:/board/boardDetail.do";
	}

	/**
	 * 상세 보기
	 * @param boardVO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/board/boardDetail.do", method=RequestMethod.GET)
	public String boardDetail(@ModelAttribute BoardVO boardVO, Model model) throws Exception {

		BoardVO board = boardSelect(boardVO);
		model.addAttribute("board", board);

		return "/board/boardDetail";
	}

	/**
	 * 수정 보기
	 * @param boardVO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/board/boardUpdateView.do")
	public String boardUpdateView(BoardVO boardVO, Model model) throws Exception {

		model.addAttribute("boardVO", boardSelect(boardVO));

		return "/board/boardRegister";
	}

	/**
	 * 수정
	 * @param boardVO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/board/boardUpdate.do")
	public String boardUpdate(@ModelAttribute BoardVO boardVO, Model model) throws Exception {

		boardService.update(boardVO);

		return "redirect:/board/boardRegister.do";
	}

	/**
	 * 삭제
	 * @param boardVO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/board/boardDelete.do")
	public String boardDelete(@ModelAttribute BoardVO boardVO, Model model) throws Exception {
		boardService.delete(boardVO);
		
		return "redirect:/board/boardList.do";
	}
	

	/**
	 * 상세 조회
	 * @param boardVO
	 * @return
	 * @throws Exception
	 */
	public BoardVO boardSelect(BoardVO boardVO) throws Exception {

		return boardService.select(boardVO);
	}

}
