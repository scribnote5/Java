package org.sdy.spring.board.vo;

import java.util.*;

import lombok.*;

@Data
public class BoardVO {
	private int boardNum;
	private String title;
	private String content;
	private String writer;
	private int viewCnt;
	private Date regDate;
	private Date updateDate;
}
