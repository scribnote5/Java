package org.sdy.spring.board.service;

import java.util.*;

import org.sdy.spring.board.vo.*;
import org.springframework.stereotype.*;

public interface BoardService {
	public List<BoardVO> selectList(BoardVO vo) throws Exception;
	public BoardVO select(BoardVO vo) throws Exception;
	public BoardVO insert(BoardVO vo) throws Exception;
	public void update(BoardVO vo) throws Exception;
	public void delete(BoardVO vo) throws Exception;
}
