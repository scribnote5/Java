package org.sdy.spring.board.service;

import java.util.*;

import javax.inject.*;

import org.apache.ibatis.session.*;
import org.sdy.spring.board.dao.*;
import org.sdy.spring.board.vo.*;
import org.springframework.stereotype.*;

@Service
public class BoardServiceImpl implements BoardService {
	
	@Inject
	private SqlSession sqlSession;
	
	@Override
	public List<BoardVO> selectList(BoardVO vo) throws Exception {
		// TODO Auto-generated method stub
		BoardDAO boardDAO = sqlSession.getMapper(BoardDAO.class);		
		return boardDAO.selectList(vo);
	}

	@Override
	public BoardVO select(BoardVO vo) throws Exception {
		// TODO Auto-generated method stub
		BoardDAO boardDAO = sqlSession.getMapper(BoardDAO.class);		
		return boardDAO.select(vo);
	}

	@Override
	public BoardVO insert(BoardVO vo) throws Exception {
		// TODO Auto-generated method stub
		BoardDAO boardDAO = sqlSession.getMapper(BoardDAO.class);		
		boardDAO.insert(vo);
		
		return vo;
	}

	@Override
	public void update(BoardVO vo) throws Exception {
		// TODO Auto-generated method stub
		BoardDAO boardDAO = sqlSession.getMapper(BoardDAO.class);
		boardDAO.update(vo);
	}

	@Override
	public void delete(BoardVO vo) throws Exception {
		// TODO Auto-generated method stub
		BoardDAO boardDAO = sqlSession.getMapper(BoardDAO.class);
		boardDAO.delete(vo);
	}

}

