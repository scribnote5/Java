package org.sdy.mybatis.board.service;

import java.util.*;

import org.sdy.mybatis.board.dao.*;
import org.sdy.mybatis.board.vo.*;

public class BoardServiceImpl implements BoardService {
	private BoardDao dao;

	// 기본 생성자
	public BoardServiceImpl() {
		BoardDao dao = new BoardDao();
		this.dao = dao;
	}

	@Override
	public List<BoardVo> selectList(BoardVo vo) {
		return dao.selectList(vo);
	}

}
