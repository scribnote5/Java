package org.sdy.mybatis.board.service;

import java.util.*;

import org.sdy.mybatis.board.vo.*;

public interface BoardService {
	public List<BoardVo> selectList(BoardVo vo);
}
