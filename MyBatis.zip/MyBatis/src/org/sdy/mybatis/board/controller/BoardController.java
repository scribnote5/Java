package org.sdy.mybatis.board.controller;

import java.util.*;

import org.sdy.mybatis.board.service.*;
import org.sdy.mybatis.board.vo.*;

public class BoardController {
	private BoardService service;

	// 기본 생성자
	public BoardController() {
		BoardService service = new BoardServiceImpl();
		this.service = service;
	}

	public List<BoardVo> selectBoardList(BoardVo boardVO) {
		List<BoardVo> boardList = service.selectList(boardVO);
		
		return boardList;
	}
}
