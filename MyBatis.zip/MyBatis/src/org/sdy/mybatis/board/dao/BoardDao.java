package org.sdy.mybatis.board.dao;

import java.util.*;

import org.apache.ibatis.session.*;
import org.sdy.mybatis.board.vo.*;
import org.sdy.mybatis.factory.*;

public class BoardDao {
	// 내부적으로 사용할 SqlSessionFactory 객체
	private SqlSessionFactory factoryMaria;
	// private SqlSessionFactory factoryMaria2;

	// 기본 생성자 : SqlSessionFactory 객체 생성
	public BoardDao() {
		factoryMaria = sqlSessionFactory.getSqlSessionFactoryMaria();
		// factoryMaria2 = sqlSessionFactory.getSqlSessionFactoryMaria2();

	}

	public List<BoardVo> selectList(BoardVo vo) {
		// SqlSession은 factory로 부터 얻어낼 때 기본 트랜잭션 옵션 : non-auto-commit
		// openSession(true) : auto-commit
		// openSession(), openSession(false) : non-auto-commit;
		SqlSession session = factoryMaria.openSession(true);
		List<BoardVo> boardVoList = null;
		try {
			boardVoList = session.selectList("BoardMapper.selectList");
		} finally {
			session.close();
		}

		return boardVoList;
	}

}
