package org.sdy.mybatis.board.vo;

import java.util.*;

import lombok.*;

@Data
public class BoardVo {
	private int boardNum;
	private String title;
	private String content;
	private String writer;
	private int viewCnt;
	private Date regDate;
	private Date updateDate;

}
