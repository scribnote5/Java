package org.sdy.mybatis.core;

import java.util.*;

import org.sdy.mybatis.board.controller.*;
import org.sdy.mybatis.board.vo.*;
import org.slf4j.*;

public class Main {
	public static void main(String[] args) {
		BoardController boardController = new BoardController();
		    
		// import : org.slf4j.* 
		Logger logger = LoggerFactory.getLogger(BoardController.class);
		logger.trace("trace");
        logger.debug("debug");
        logger.info("info");
        logger.warn("warn");
        logger.error("error");

		List<BoardVo> boardVoList = boardController.selectBoardList(null);
		System.out.println(boardVoList);

	}
}
