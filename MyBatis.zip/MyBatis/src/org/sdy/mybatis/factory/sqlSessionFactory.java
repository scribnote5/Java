package org.sdy.mybatis.factory;

import java.io.IOException;
import java.io.InputStream;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

/**
 * Mybatis의 sqlsessionFactory 객체를 싱글턴으로 생성하고 관리하는 클래스
 * 
 * @author scrib
 *
 */
public class sqlSessionFactory {
	// 싱글턴으로 관리해야 하는 sqlsessionFactory 인스턴스 선언
	public static SqlSessionFactory connMaria;
	public static SqlSessionFactory connMaria2;

	// SqlSessionFactory 초기화
	private sqlSessionFactory() {
		String resource = "mybatis-config.xml";
		InputStream in = null;

		try {
			in = Resources.getResourceAsStream(resource);
			connMaria = new SqlSessionFactoryBuilder().build(in, "Maria");
			// connMaria2 = new SqlSessionFactoryBuilder().build(in, "Maria2");
		} catch (IOException ioe) {
			System.err.println("mybatis 설정 읽기 오류");
			ioe.printStackTrace();
		}
	}

	public static SqlSessionFactory getSqlSessionFactoryMaria() {
		if (connMaria == null) {
			new sqlSessionFactory();
		}

		return connMaria;
	}

	public static SqlSessionFactory getSqlSessionFactoryMaria2() {
		if (connMaria2 == null) {
			new sqlSessionFactory();
		}

		return connMaria2;
	}

}
